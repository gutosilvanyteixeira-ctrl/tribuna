# Tribuna — gestão de Public Speaking

Aplicação web independente, em português, com páginas públicas, links privados para a equipe Speaker e contas administrativas com usuário e senha. Não utiliza login, APIs ou conta do ChatGPT. A planilha e os manuais serviram como referência de regras; nenhum participante, e-mail ou resultado daqueles arquivos foi importado.

## Estado da entrega

Implementação executável com páginas geradas no servidor, banco SQLite persistente, fila de e-mails e pacote Docker. Não está publicada em um domínio. A conta inicial ainda não existe: crie-a com seu e-mail e uma senha escolhida por você. O envio real exige configuração SMTP. Os testes usam dados fictícios e bancos temporários descartados ao terminar.

## Executar localmente

Requer Python 3.12 ou superior. A aplicação e os testes usam apenas a biblioteca padrão. Gunicorn é necessário somente na execução de produção indicada abaixo.

```bash
python manage.py init
python manage.py bootstrap --email SEU_EMAIL --username gustavo.silvany
python app.py
```

Abra `http://localhost:8000/login` para a administração. A raiz do site é a página pública para visitantes sem sessão. O comando solicita a senha pelo terminal sem exibi-la ou salvá-la em texto simples. O cadastro inicial identifica Gustavo Silvany, SDS UFBA, como moderador global e pessoa autorizada a criar campeonatos. Não cria vínculos com campeonatos alheios.

Para enviar e-mails, configure as variáveis do provedor SMTP e execute em outro processo:

```bash
python mail_worker.py
```

O servidor local se vincula apenas ao computador local e é destinado a desenvolvimento. Não o exponha diretamente à internet.

## Publicar em hospedagem independente

É necessário um servidor com Docker, armazenamento persistente e saída SMTP. Não funciona como um conjunto de páginas estáticas nem como uma função sem disco persistente. Este pacote usa uma única instância lógica de banco em volume local compartilhado por web e worker de e-mail.

1. Copie `.env.example` para `.env` e defina `BASE_URL` com o endereço HTTPS exato, sem barra final.
2. Preencha `SMTP_HOST`, `SMTP_PORT`, `SMTP_TLS`, `SMTP_USER`, `SMTP_PASSWORD` e `SMTP_FROM` com dados do serviço de envio autorizado. Use `starttls` (normalmente porta 587) ou `ssl` (normalmente 465).
3. Execute `docker compose up -d --build`.
4. Crie a conta inicial com `docker compose exec web python manage.py bootstrap --email SEU_EMAIL`.
5. Configure um proxy HTTPS para encaminhar ao serviço em `127.0.0.1:8000`, preservando o cabeçalho Host. O processo web não confia em cabeçalhos arbitrários de IP encaminhados. Configure limitação de requisições também no proxy; o limite por usuário funciona na aplicação.
6. Teste a recuperação de senha, um convite para endereço controlado, o isolamento entre dois campeonatos e a entrega de um alerta de equidade antes do primeiro evento real.

O domínio, a conta de hospedagem, o endereço inicial de Gustavo e as credenciais SMTP não foram fornecidos. Portanto, publicação, HTTPS público e entrega real de e-mails ainda não foram verificados. O build Docker/Gunicorn também deve ser executado na hospedagem; os testes locais exercitam diretamente a aplicação WSGI.

Em uma hospedagem que oferece disco persistente para apenas um serviço, use `python run_service.py` como comando de início. Ele inicia web e fila no mesmo serviço, respeita a variável `PORT` e encerra ambos se um processo falhar, permitindo ao supervisor da hospedagem reiniciar o conjunto. Configure `DATABASE_PATH` dentro do disco montado. Não inicie o serviço de e-mail separado do Compose nesse modo. Não aumente o número de instâncias horizontais usando cópias independentes do banco.

Nunca coloque senhas em arquivos versionados, mensagens, logs ou código. `.env` e os bancos estão excluídos do pacote e da imagem. O proxy não deve registrar parâmetros de consulta de `/invite`, `/reset` ou `/judge`, que contêm chaves de acesso.

## Permissões

- **Moderador global:** convida organizadores e outros moderadores, gerencia permissões e situação das contas e cadastra sociedades. Essa função não concede leitura nem alteração de campeonatos. Não existe botão de personificação de usuário ou acesso administrativo irrestrito ao conteúdo dos eventos.
- **Organizador autorizado na plataforma:** pode criar campeonatos. A criação dá acesso de organização somente ao novo campeonato.
- **Organização de um campeonato:** gerencia inscritos, equipe, salas, regras, penalidades, ausências, encerramentos, publicação, e-mails e break. Quem tem somente a função administrativa, sem ser juiz, pode ver as notas antes da liberação geral. Não lança notas por ser organizador: precisa ser SM ou NSM para isso.
- **SM e NSM:** todos integram automaticamente a organização do campeonato e possuem suas funções de gestão. Isso vale para registros existentes, contas com senha e links privados. O sigilo das notas é preservado: mesmo sendo organizadores, os juízes não veem as notas dos colegas, sua auditoria ou a classificação antes do encerramento das três classificatórias. Podem corrigir suas próprias notas com justificativa e lançar uma avaliação ainda pendente em nome de outro juiz com justificativa, sem sobrescrever uma avaliação existente do colega. A operação identifica o autor real e o juiz representado.
- **Advisor:** acompanha o campeonato, sem lançar notas ou administrar. Resultados e notas alheias são liberados após as classificatórias. A função não pode acumular SM/NSM.
- **Equidade:** acesso separado a inscritos, juízes, impedimentos e seus alertas. Não acessa pontuação, classificação ou administração. Não acumula outras funções no mesmo campeonato.

Permissões são verificadas em cada requisição no servidor. Convites de conta são vinculados ao e-mail, expiram em sete dias e só podem ser aceitos uma vez. Quem já tem conta com senha precisa estar autenticado na conta do e-mail convidado. O nome de usuário é independente do e-mail.

## Acesso público e links privados

Oradores e público não têm conta nem recebem link privado. Acessam `/public` e `/public/ID` livremente. Cada campeonato começa não publicado. Na aba **Publicação**, a organização escolhe liberar a página, nomes e sociedades dos inscritos, equipe Speaker, salas/mesas por rodada, classificação e tops, break e campeão. A classificação só pode ser publicada depois do encerramento das três classificatórias. A aplicação volta a ocultá-la se uma rodada for reaberta. E-mails, vídeos, notas individuais por juiz, motivos de impedimento e histórico não fazem parte da projeção pública.

Na aba **Equipe**, “Cadastrar SM/NSM e enviar link privado” registra a identidade e coloca o link na fila de e-mail. O juiz não precisa escolher usuário nem senha. Ao abrir o link, confirma a entrada no campeonato; a chave dá acesso a julgamento e organização daquele evento, nunca à moderação global ou a outros campeonatos, ainda que a mesma pessoa tenha essas permissões em sua conta administrativa.

O link usa 32 bytes aleatórios, é guardado por hash na tabela de autenticação e tem validade configurável de 1 a 365 dias (padrão de 90). A cópia necessária para entrega existe no corpo da mensagem na fila, que não é exposto pela interface. A organização pode emitir novo link ou revogar o atual, sempre com justificativa. Revogar ou substituir invalida as sessões derivadas na requisição seguinte. O histórico registra a operação e a identidade, sem gravar a chave. O link é uma credencial: quem o possuir pode agir com as funções da pessoa naquele campeonato.

Os demais membros de organização, Advisor e equidade mantêm os acessos com senha. Contas de juiz com senha já existentes continuam funcionando; o link é uma alternativa por campeonato. Para promover uma identidade que só usa link a uma conta administrativa, envie um convite de conta ao e-mail correspondente e defina a senha na aceitação.

## Fluxo de um campeonato

1. Um organizador autorizado cria o campeonato e ajusta regras antes da primeira nota.
2. Cadastra oradores com nome, e-mail e sociedade. Há as 11 sociedades solicitadas e cadastro de novas sociedades.
3. Cadastra SM e NSM para receberem links privados, ou mantém contas individuais existentes. Todos eles integram a organização. Convida os demais organizadores, Advisor e equidade por e-mail para criarem suas senhas; senhas nunca são enviadas por e-mail.
4. A equidade cadastra impedimentos juiz–orador e juiz–juiz. O motivo fica restrito à equidade.
5. Sorteia a primeira rodada. Nas demais, se a quantidade de salas e os participantes forem os mesmos, a distribuição inicial dos oradores é mantida; as mesas são sorteadas novamente. Os nomes das salas permanecem numerados.
6. O sorteio equilibra tamanho e sociedades dos oradores e procura reduzir impedimentos, relações de sociedade e mesas sem SM. A busca é probabilística, com 1.000 tentativas: não promete encontrar toda solução possível. Conflitos remanescentes ficam sinalizados para ajuste manual.
7. A organização ajusta salas, ordem, mesas e presidente. Fecha as salas e abre a avaliação. Mudanças posteriores geram avisos para organização e juízes. Um juiz só pode integrar uma sala por rodada.
8. Cada juiz lança as cinco notas. O sistema mostra apenas um alerta genérico se as duas somas diferirem por quatro ou mais pontos. A mesa ou organização pode justificar a manutenção; nova alteração de nota invalida a justificativa anterior.
9. A organização registra links, duração, penalidades e ausências. Um orador sem apresentação em qualquer classificatória fica fora da classificação geral. O estado “não participou do campeonato” também o exclui.
10. Encerra as três rodadas. Somente então os juízes veem as avaliações alheias e a classificação. Correções de rodada encerrada exigem reabertura com justificativa, antes do break.
11. Define se o top de discursos admite repetição de orador e o tamanho do top. Resolve eventuais sorteios pendentes e gera o break.
12. Escolhe somente final ou duas semifinais, número de classificados e juízes, e quantos avançam por semifinal. As semifinais usam distribuição equilibrada por colocação: para 12, 1/4/5/8/9/12 e 2/3/6/7/10/11. Os demais oradores classificados formam reservas.
13. O presidente de cada semifinal seleciona os classificados. Após ambas as decisões, a Final de PS é criada automaticamente para a organização definir sua mesa. Na final, somente seu presidente informa o campeão.
14. Publica as informações desejadas na aba Publicação. Os oradores acompanham pela página pública, sem contas individuais.

## Cálculos e convenções

Cada critério aceita apenas um inteiro de 0 a 15: linguagem verbal, linguagem não verbal, conteúdo, engajamento e estrutura. A soma de um juiz vai de 0 a 75.

`nota do discurso = (soma do juiz A + soma do juiz B) / 2 − penalidade`

`média geral = (discurso R1 + discurso R2 + discurso R3) / 3`

O cálculo usa frações exatas, sem arredondamento para ordenar. A tela apresenta até duas casas decimais. Penalidades manuais aceitam até duas casas decimais. No modo automático, o desconto é `máximo(0, duração − limite − tolerância) × desconto por segundo`. O padrão do manual é 180 segundos, tolerância de 10 e 0,20 ponto/segundo; a organização pode configurar antes das notas. Não há piso automático em zero para notas após desconto, pois esse piso não foi solicitado.

A classificação desempata por Golden, Silver e Bronze (notas de discurso já penalizadas, em ordem decrescente), depois sorteio criptograficamente aleatório com resultado persistido e auditado. Atualizar a página não refaz o sorteio. Com três rodadas, médias exatamente iguais e Golden/Silver iguais implicam Bronze igual; o critério foi mantido para respeitar o regulamento.

Os melhores discursos usam as mesmas notas penalizadas e permitem escolher entre Golden/Silver/Bronze ou maior nota individual (com desconto) seguida da segunda melhor média. Empates remanescentes nesse ranking compartilham colocação; o corte do top segue a quantidade solicitada. Os rankings por critério são a média das seis notas individuais, sem transferir a penalidade de tempo para um critério. Nesta versão, os rankings de premiação incluem somente participantes aptos na classificação geral.

## Integridade e operação

- Registro de autor, data em UTC, justificativa e valores anteriores/novos. A própria aplicação não permite editar nem excluir a auditoria; gatilhos do banco impedem essas operações e os eventos formam uma cadeia de hashes.
- Essa cadeia permite detectar alterações, mas não é uma garantia contra quem controla fisicamente o servidor e reescreve todo o banco. Mantenha backups externos e armazene o último hash em um local independente para auditoria externa.
- Cada envio tem identificador único para evitar duplicação por duplo clique. Alterações de nota usam versão para detectar concorrência.
- Senhas derivadas com scrypt e salt individual; sessões opacas armazenadas por hash no servidor, expiração em oito horas, cookies HttpOnly/SameSite e Secure quando HTTPS. Proteção CSRF, validação de Host/Origin, limitação de tentativas e cabeçalhos de segurança.
- O início da quebra de um impedimento gera uma notificação para cada membro da equidade e uma mensagem na fila de e-mail na mesma transação. A entrega depende do SMTP, portanto não pode ser garantida como instantânea. O worker verifica a fila a cada poucos segundos.
- A fila possui retentativas, Message-ID estável e erro visível. Uma falha após o SMTP aceitar uma mensagem pode causar reenvio; não se promete entrega “exatamente uma vez”. O estado “enviado” significa aceitação pelo servidor SMTP, não confirmação de leitura ou entrega à caixa de entrada.
- Não há como invalidar o break já gerado pela interface. Reabrir classificatórias após gerar fases dependentes fica bloqueado para evitar resultados contraditórios. Da mesma forma, uma semifinal não pode ser corrigida depois que suas decisões geraram a final. Uma regra futura de anulação de fases precisa ser definida antes de liberar esse tipo de alteração.
- O serviço de e-mail usa um remetente autenticado da instalação. Cada campeonato pode personalizar mensagem, links e Reply-To. Enviar com o endereço de cada campeonato como remetente exigiria verificar esse remetente com o provedor.

## Testar e manter

```bash
python -m unittest discover -s tests -v
python manage.py verify-audit
python manage.py backup /caminho-seguro/backup-2026-10-12.db
```

As verificações cobrem autenticação própria, links privados e sua revogação, publicação seletiva, CSRF, limite de tentativas, sigilo de juízes que também são organizadores, isolamento de campeonato, equidade, permissões, auditoria, notas, penalidades, desempates, geração de eliminatórias e renderização HTTP das páginas. A interface responsiva foi implementada em CSS; não houve inspeção visual em navegador nesta execução.

Faça backup com o comando próprio, que usa a API de backup do SQLite e é consistente mesmo com WAL. Não copie somente o arquivo `.db` de um banco aberto. Proteja os backups, pois contêm e-mails, hashes de senha e motivos confidenciais. Teste restauração em ambiente separado. Para reprocessar falhas de e-mail, após verificar a situação no provedor: `python manage.py retry-emails`.

Arquivos principais: `core.py` (banco, identidade e auditoria), `domain.py` (regras), `app.py` (HTTP e autenticação), `views.py` (telas), `static/` (estilo e interações), `mail_worker.py` (envio), `manage.py` (instalação e manutenção), `tests/` (verificações).
