"""Persistence, authentication and append-only audit primitives."""
import os, sqlite3, json, secrets, hashlib, hmac, time, re
from contextlib import contextmanager
from pathlib import Path
from contextvars import ContextVar

ROOT = Path(__file__).parent
DB = os.environ.get('DATABASE_PATH', str(ROOT / 'data' / 'tribuna.db'))
BASE_URL = os.environ.get('BASE_URL', 'http://localhost:8000').rstrip('/')
SOCIETIES = ['SDS UFBA','SDUFRJ','GDO UFRGS','SdDUFSC','OCTÓGONO','SdDUFC','SENATUS UFMG','ÁGORA UFS','SdDUNIFOR','GEDE UFPR','SDP UFRN']
CRITERIA = ['Linguagem verbal','Linguagem não verbal','Conteúdo','Engajamento','Estrutura']
DEFAULTS = dict(penalty_mode='manual',limit_seconds=180,tolerance_seconds=10,rate_cents=20,speech_tie='golden',repeat_speakers=False,top_size=10,mail_subject='Informações — {campeonato}',mail_body='Olá, {nome}!\n\nBem-vindo(a) ao {campeonato}.\n\nLinks importantes:\n{links}\n\nEquipe organizadora',links='',reply_to='')
ACCESS_SCOPE=ContextVar('judge_access_scope',default=None)
PUBLIC_DEFAULTS={'enabled':False,'intro':'','roster':False,'team':False,'rounds':[],'rankings':False,'break':False,'champion':False}

SCHEMA = '''
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE COLLATE NOCASE, email TEXT UNIQUE COLLATE NOCASE, name TEXT NOT NULL, society TEXT NOT NULL, password TEXT NOT NULL, moderator INTEGER NOT NULL DEFAULT 0, organizer INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER REFERENCES users(id),csrf TEXT NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS attempts(bucket TEXT PRIMARY KEY,count INTEGER NOT NULL,until INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS competitions(id INTEGER PRIMARY KEY,name TEXT NOT NULL,config TEXT NOT NULL,created_by INTEGER REFERENCES users(id),break_spec TEXT);
CREATE TABLE IF NOT EXISTS memberships(c INTEGER REFERENCES competitions(id),u INTEGER REFERENCES users(id),roles TEXT NOT NULL,PRIMARY KEY(c,u));
CREATE TABLE IF NOT EXISTS societies(name TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS invites(id INTEGER PRIMARY KEY,token TEXT UNIQUE NOT NULL,email TEXT NOT NULL,name TEXT NOT NULL,society TEXT NOT NULL,c INTEGER REFERENCES competitions(id),roles TEXT NOT NULL,global_role TEXT,expires INTEGER NOT NULL,used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS resets(token TEXT PRIMARY KEY,u INTEGER REFERENCES users(id),expires INTEGER NOT NULL,used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS participants(id INTEGER PRIMARY KEY,c INTEGER REFERENCES competitions(id),name TEXT NOT NULL,email TEXT NOT NULL,society TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active',UNIQUE(c,email));
CREATE TABLE IF NOT EXISTS rounds(c INTEGER REFERENCES competitions(id),n INTEGER NOT NULL,state TEXT NOT NULL DEFAULT 'draft',PRIMARY KEY(c,n));
CREATE TABLE IF NOT EXISTS rooms(id INTEGER PRIMARY KEY,c INTEGER REFERENCES competitions(id),n INTEGER NOT NULL,name TEXT NOT NULL,chair INTEGER REFERENCES users(id),advance INTEGER NOT NULL DEFAULT 0,result TEXT,UNIQUE(c,n,name));
CREATE TABLE IF NOT EXISTS placements(c INTEGER REFERENCES competitions(id),n INTEGER NOT NULL,p INTEGER REFERENCES participants(id),room INTEGER REFERENCES rooms(id),position INTEGER NOT NULL,PRIMARY KEY(c,n,p));
CREATE TABLE IF NOT EXISTS panels(room INTEGER REFERENCES rooms(id),u INTEGER REFERENCES users(id),PRIMARY KEY(room,u));
CREATE TABLE IF NOT EXISTS speeches(c INTEGER REFERENCES competitions(id),p INTEGER REFERENCES participants(id),n INTEGER NOT NULL,url TEXT NOT NULL DEFAULT '',absent INTEGER NOT NULL DEFAULT 0,seconds INTEGER,penalty INTEGER NOT NULL DEFAULT 0,reason TEXT NOT NULL DEFAULT '',PRIMARY KEY(c,p,n));
CREATE TABLE IF NOT EXISTS scores(c INTEGER REFERENCES competitions(id),p INTEGER REFERENCES participants(id),n INTEGER NOT NULL,j INTEGER REFERENCES users(id),values_json TEXT NOT NULL,submitted_by INTEGER REFERENCES users(id),version INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(c,p,n,j));
CREATE TABLE IF NOT EXISTS waivers(c INTEGER,p INTEGER,n INTEGER,signature TEXT NOT NULL,reason TEXT NOT NULL,PRIMARY KEY(c,p,n));
CREATE TABLE IF NOT EXISTS conflicts(id INTEGER PRIMARY KEY,c INTEGER REFERENCES competitions(id),judge INTEGER REFERENCES users(id),kind TEXT NOT NULL,target INTEGER NOT NULL,reason TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS breaches(conflict INTEGER REFERENCES conflicts(id),room INTEGER REFERENCES rooms(id),active INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(conflict,room));
CREATE TABLE IF NOT EXISTS draws(c INTEGER REFERENCES competitions(id),signature TEXT NOT NULL,ordering TEXT NOT NULL,PRIMARY KEY(c,signature));
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,c INTEGER REFERENCES competitions(id),u INTEGER REFERENCES users(id),message TEXT NOT NULL,created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY,c INTEGER REFERENCES competitions(id),recipient TEXT NOT NULL,subject TEXT NOT NULL,body TEXT NOT NULL,reply_to TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'pending',attempts INTEGER NOT NULL DEFAULT 0,next_try INTEGER NOT NULL DEFAULT 0,error TEXT NOT NULL DEFAULT '',message_key TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,c INTEGER,actor INTEGER,action TEXT NOT NULL,object TEXT NOT NULL,before_json TEXT NOT NULL,after_json TEXT NOT NULL,reason TEXT NOT NULL,visibility TEXT NOT NULL DEFAULT 'general',created INTEGER NOT NULL,previous TEXT NOT NULL,digest TEXT NOT NULL);
CREATE TRIGGER IF NOT EXISTS no_audit_update BEFORE UPDATE ON audit BEGIN SELECT RAISE(ABORT,'Audit is append-only'); END;
CREATE TRIGGER IF NOT EXISTS no_audit_delete BEFORE DELETE ON audit BEGIN SELECT RAISE(ABORT,'Audit is append-only'); END;
CREATE TABLE IF NOT EXISTS operations(user INTEGER,token TEXT,PRIMARY KEY(user,token));
CREATE TABLE IF NOT EXISTS judge_links(id INTEGER PRIMARY KEY,c INTEGER REFERENCES competitions(id),u INTEGER REFERENCES users(id),token TEXT UNIQUE NOT NULL,expires INTEGER NOT NULL,revoked INTEGER NOT NULL DEFAULT 0,created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS session_links(session TEXT PRIMARY KEY REFERENCES sessions(token) ON DELETE CASCADE,link INTEGER NOT NULL REFERENCES judge_links(id));
'''

class Problem(Exception):
    def __init__(self,message,status=400): self.message,self.status=message,status

def connect():
    Path(DB).parent.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(DB,timeout=20,isolation_level=None)
    db.row_factory=sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA busy_timeout=20000')
    return db

def init():
    with connect() as db:
        db.executescript(SCHEMA)
        db.executemany('INSERT OR IGNORE INTO societies VALUES (?)',[(s,) for s in SOCIETIES])

@contextmanager
def transaction(db):
    db.execute('BEGIN IMMEDIATE')
    try: yield; db.execute('COMMIT')
    except BaseException: db.execute('ROLLBACK'); raise

def rows(db,sql,args=()): return [dict(x) for x in db.execute(sql,args)]
def one(db,sql,args=()):
    r=db.execute(sql,args).fetchone()
    return dict(r) if r else None
def js(value): return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def digest(value): return hashlib.sha256(value.encode()).hexdigest()
def now(): return int(time.time())
def required(data,key,limit=500):
    v=str(data.get(key,'')).strip()
    if not v or len(v)>limit: raise Problem('Preencha corretamente: '+key)
    return v
def integer(data,key,low=0,high=9999):
    v=str(data.get(key,''))
    if not re.fullmatch(r'\d+',v) or not low<=int(v)<=high: raise Problem('Valor inválido: '+key)
    return int(v)
def email(value):
    value=value.strip().lower()
    if len(value)>254 or not re.fullmatch(r'[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+',value): raise Problem('E-mail inválido.')
    return value
def password_hash(password):
    if len(password)<12 or len(password)>200: raise Problem('Use uma senha entre 12 e 200 caracteres.')
    salt=secrets.token_hex(16)
    hashed=hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1).hex()
    return salt+':'+hashed
def password_ok(password,saved):
    try:
        salt,expected=saved.split(':')
        actual=hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1).hex()
        return hmac.compare_digest(actual,expected)
    except (ValueError,TypeError): return False

def audit(db,c,actor,action,obj,before=None,after=None,reason='',visibility='general'):
    prev=one(db,'SELECT digest FROM audit ORDER BY id DESC LIMIT 1')
    prev=prev['digest'] if prev else '0'*64
    payload=[c,actor,action,str(obj),js(before),js(after),reason,visibility,now(),prev]
    db.execute('INSERT INTO audit(c,actor,action,object,before_json,after_json,reason,visibility,created,previous,digest) VALUES (?,?,?,?,?,?,?,?,?,?,?)',(*payload,digest(js(payload))))

def roles(db,c,u):
    scope=ACCESS_SCOPE.get()
    if scope and scope['u']==u and scope['c']!=c: return set()
    r=one(db,'SELECT roles FROM memberships WHERE c=? AND u=?',(c,u))
    rr=effective_roles(json.loads(r['roles'])) if r else set()
    return rr
def effective_roles(stored):
    rr=set(stored)
    if rr&{'SM','NSM'}: rr.add('organizer')
    return rr
def allow(db,c,u,*allowed):
    r=roles(db,c,u)
    if not r or (allowed and not r.intersection(allowed)): raise Problem('Você não tem acesso a esta operação neste campeonato.',403)
    return r
def competition(db,c):
    r=one(db,'SELECT * FROM competitions WHERE id=?',(c,))
    if not r: raise Problem('Campeonato não encontrado.',404)
    r['config']=json.loads(r['config'])
    return r

def public_config(comp): return dict(PUBLIC_DEFAULTS,**comp['config'].get('public',{}))

def judge_link(db,token):
    r=one(db,'SELECT l.*,u.name,u.active FROM judge_links l JOIN users u ON u.id=l.u WHERE l.token=? AND l.revoked=0 AND l.expires>?',(digest(token),now()))
    if not r or not r['active']: raise Problem('Link privado inválido, revogado ou expirado.',403)
    membership=one(db,'SELECT roles FROM memberships WHERE c=? AND u=?',(r['c'],r['u']))
    if not membership or not set(json.loads(membership['roles']))&{'SM','NSM'}: raise Problem('Este link não possui mais acesso de juiz.',403)
    return r

def create_judge_link(db,actor,c,uid,days,why):
    allow(db,c,actor['id'],'organizer')
    target=one(db,'SELECT id,email,name,active FROM users WHERE id=?',(uid,))
    if not target or not target['active'] or not roles(db,c,uid)&{'SM','NSM'}: raise Problem('Selecione um juiz ativo deste campeonato.')
    if not 1<=days<=365: raise Problem('Validade deve ser de 1 a 365 dias.')
    previous=rows(db,'SELECT id FROM judge_links WHERE c=? AND u=? AND revoked=0',(c,uid))
    db.execute('UPDATE judge_links SET revoked=1 WHERE c=? AND u=?',(c,uid))
    token=secrets.token_urlsafe(32);expires=now()+days*86400
    lid=db.execute('INSERT INTO judge_links(c,u,token,expires,created) VALUES (?,?,?,?,?)',(c,uid,digest(token),expires,now())).lastrowid
    comp=competition(db,c)
    enqueue(db,c,target['email'],'Seu link privado de juiz — Tribuna',f"Olá, {target['name']}!\n\nAcesse suas avaliações de {comp['name']} por este link, sem criar senha:\n{BASE_URL}/judge?token={token}\n\nEste link é pessoal: quem o possuir poderá realizar as ações de juiz em seu nome. Não o compartilhe. Validade: {days} dias. Um novo link invalida o anterior.")
    audit(db,c,actor['id'],'Link de juiz emitido',uid,before=dict(replaced=[x['id'] for x in previous]),after=dict(link_id=lid,expires=expires),reason=why)
    return lid

def add_judge_with_link(db,actor,c,data):
    allow(db,c,actor['id'],'organizer')
    name=required(data,'name');address=email(required(data,'email'));society=required(data,'society');role=required(data,'role')
    if role not in ('SM','NSM'): raise Problem('Escolha SM ou NSM.')
    if not one(db,'SELECT 1 FROM societies WHERE name=?',(society,)): raise Problem('Sociedade inválida.')
    target=one(db,'SELECT * FROM users WHERE email=?',(address,))
    if target:
        if not target['active']: raise Problem('A conta está desativada. Consulte a moderação.')
        # Do not silently overwrite the identity of an existing account.
        if target['name']!=name or target['society']!=society: raise Problem('Já existe uma identidade com este e-mail. Use o nome e a sociedade cadastrados, ou solicite correção à moderação.')
        uid=target['id']
    else:
        uid=db.execute('INSERT INTO users(username,email,name,society,password) VALUES (?,?,?,?,?)',('judge.'+secrets.token_hex(12),address,name,society,'!link-only')).lastrowid
    before=roles(db,c,uid)
    if before&{'equity','advisor'}: raise Problem('Esta pessoa tem função incompatível com julgamento neste campeonato.')
    rr=(before-{'SM','NSM'})|{role}
    db.execute('INSERT INTO memberships VALUES (?,?,?) ON CONFLICT(c,u) DO UPDATE SET roles=excluded.roles',(c,uid,js(sorted(rr))))
    audit(db,c,actor['id'],'Juiz cadastrado para link privado',uid,before=sorted(before),after=sorted(rr))
    return create_judge_link(db,actor,c,uid,integer(data,'days',1,365),'Cadastro de juiz')
def enqueue(db,c,to,subject,body,reply_to='',key=None):
    if '\n' in subject or '\r' in subject: raise Problem('Assunto inválido.')
    db.execute('INSERT OR IGNORE INTO outbox(c,recipient,subject,body,reply_to,message_key) VALUES (?,?,?,?,?,?)',(c,email(to),subject,body,reply_to,key or secrets.token_hex(16)))
def notify(db,c,users,message,mail=False):
    for u in set(users):
        db.execute('INSERT INTO notifications(c,u,message,created) VALUES (?,?,?,?)',(c,u,message,now()))
        if mail:
            target=one(db,'SELECT email FROM users WHERE id=?',(u,))
            if target: enqueue(db,c,target['email'],'Tribuna — aviso do campeonato',message+'\n\n'+BASE_URL+'/t/'+str(c))

def issue_invite(db,actor,data,c=None):
    address=email(required(data,'email')); name=required(data,'name'); society=required(data,'society')
    if not one(db,'SELECT name FROM societies WHERE name=?',(society,)): raise Problem('Cadastre a sociedade primeiro.')
    global_role=None
    if c is None:
        if not actor['moderator']: raise Problem('Somente a moderação global.',403)
        global_role=required(data,'global_role')
        if global_role not in ('organizer','moderator'): raise Problem('Permissão inválida.')
        rr=[]
    else:
        allow(db,c,actor['id'],'organizer')
        rr=list(dict.fromkeys(data.get('roles',[])))
        if not rr or set(rr)-{'organizer','SM','NSM','advisor','equity'}: raise Problem('Selecione as funções.')
        if 'equity' in rr and len(rr)>1: raise Problem('Equidade possui acesso separado e não acumula outras funções no mesmo campeonato.')
        if 'advisor' in rr and set(rr)&{'SM','NSM'}: raise Problem('Advisor não é juiz.')
        if 'SM' in rr and 'NSM' in rr: raise Problem('Selecione SM ou NSM.')
    token=secrets.token_urlsafe(32)
    db.execute('INSERT INTO invites(token,email,name,society,c,roles,global_role,expires) VALUES (?,?,?,?,?,?,?,?)',(digest(token),address,name,society,c,js(rr),global_role,now()+7*86400))
    enqueue(db,c,address,'Convite para o Tribuna',f'Olá, {name}!\n\nVocê recebeu um convite para acessar o Tribuna. Defina seu usuário e senha ou entre em sua conta para aceitar:\n{BASE_URL}/invite?token={token}\n\nO convite expira em 7 dias.')
    audit(db,c,actor['id'],'Convite emitido',address,after=dict(roles=rr,global_role=global_role))

def consume_invite(db,token,data,logged=None):
    inv=one(db,'SELECT * FROM invites WHERE token=? AND used=0 AND expires>?',(digest(token),now()))
    if not inv: raise Problem('Convite inválido, utilizado ou expirado.')
    user=one(db,'SELECT * FROM users WHERE email=?',(inv['email'],))
    if user and user['password']=='!link-only':
        username=required(data,'username',50)
        if not re.fullmatch('[a-zA-Z0-9_.-]{3,50}',username): raise Problem('Usuário: 3 a 50 letras, números, pontos, hífens ou sublinhados.')
        uid=user['id']
        db.execute('UPDATE users SET username=?,password=? WHERE id=?',(username,password_hash(required(data,'password',200)),uid))
    elif user:
        if not logged or logged['id']!=user['id']: raise Problem('Entre na conta vinculada ao e-mail do convite e abra este link novamente.',403)
        uid=user['id']
    else:
        username=required(data,'username',50)
        if not re.fullmatch('[a-zA-Z0-9_.-]{3,50}',username): raise Problem('Usuário: 3 a 50 letras, números, pontos, hífens ou sublinhados.')
        uid=db.execute('INSERT INTO users(username,email,name,society,password) VALUES (?,?,?,?,?)',(username,inv['email'],inv['name'],inv['society'],password_hash(required(data,'password',200)))).lastrowid
    if inv['c']:
        old_roles=roles(db,inv['c'],uid)
        new_roles=set(json.loads(inv['roles']))
        if 'organizer' in old_roles and 'organizer' not in new_roles:
            others=[m for m in rows(db,'SELECT u,roles FROM memberships WHERE c=? AND u!=?',(inv['c'],uid)) if 'organizer' in json.loads(m['roles'])]
            if not others: raise Problem('Não é possível remover o último organizador por convite.')
        if not new_roles.intersection({'SM','NSM'}) and one(db,'SELECT 1 FROM panels p JOIN rooms r ON r.id=p.room WHERE r.c=? AND p.u=?',(inv['c'],uid)):
            raise Problem('A pessoa ainda está alocada como juiz. Resolva as mesas antes de alterar a função.')
        db.execute('INSERT INTO memberships VALUES (?,?,?) ON CONFLICT(c,u) DO UPDATE SET roles=excluded.roles',(inv['c'],uid,inv['roles']))
        audit(db,inv['c'],uid,'Vínculo de equipe aceito',uid,before=sorted(old_roles),after=sorted(new_roles))
    if inv['global_role']:
        field=inv['global_role']
        db.execute('UPDATE users SET '+field+'=1 WHERE id=?',(uid,))
    db.execute('UPDATE invites SET used=1 WHERE id=?',(inv['id'],))
    audit(db,inv['c'],uid,'Convite aceito',uid,after=dict(roles=json.loads(inv['roles']),global_role=inv['global_role']))
    return uid
