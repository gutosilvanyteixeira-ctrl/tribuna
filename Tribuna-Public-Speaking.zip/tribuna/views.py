"""Server-rendered Portuguese interface. Escape all user-authored strings."""
import html, json, secrets, datetime
from fractions import Fraction
from core import *
from domain import *

def e(x): return html.escape(str(x if x is not None else ''),quote=True)
def number(x):
    if x is None: return '—'
    return f'{float(x):.2f}'.rstrip('0').rstrip('.').replace('.',',')
def dt(x): return datetime.datetime.fromtimestamp(x,datetime.timezone.utc).strftime('%d/%m/%Y %H:%M UTC')
def pill(text,kind=''): return '<span class="pill '+e(kind)+'">'+e(text)+'</span>'
def link(url,text,cls=''): return '<a class="'+e(cls)+'" href="'+e(url)+'">'+e(text)+'</a>'
def field(name,label,value='',type='text',required=True,extra=''):
    return f'<label>{e(label)}<input type="{e(type)}" name="{e(name)}" value="{e(value)}" {"required" if required else ""} {extra}></label>'
def area(name,label,value='',required=True): return f'<label>{e(label)}<textarea name="{e(name)}" {"required" if required else ""} rows="4">{e(value)}</textarea></label>'
def select(name,label,options,current='',multiple=False):
    opts=''.join(f'<option value="{e(k)}" {"selected" if (str(k) in [str(v) for v in current] if multiple else str(k)==str(current)) else ""}>{e(v)}</option>' for k,v in options)
    return f'<label>{e(label)}<select name="{e(name)}" {"multiple size=5" if multiple else ""} required>{opts}</select></label>'
def check(name,label,checked=False): return f'<label class="check"><input type="checkbox" name="{e(name)}" value="yes" {"checked" if checked else ""}>{e(label)}</label>'
def hidden(name,value): return f'<input type="hidden" name="{e(name)}" value="{e(value)}">'
def form(ctx,action,body,button='Salvar',extras=None):
    base=hidden('csrf',ctx['csrf'])+hidden('operation',secrets.token_urlsafe(24))
    for k,v in (extras or {}).items(): base+=hidden(k,v)
    return f'<form method="post" action="{e(action)}">{base}{body}<button type="submit">{e(button)}</button></form>'
def action_form(ctx,action,body,button='Salvar',extras=None): return form(ctx,f"/t/{ctx['c']['id']}/{action}",body,button,extras)
def card(title,body,subtitle=''): return '<section class="card"><header><h2>'+e(title)+'</h2>'+('<p>'+e(subtitle)+'</p>' if subtitle else '')+'</header>'+body+'</section>'
def table(head,body):
    return '<div class="table-wrap"><table><thead><tr>'+''.join('<th>'+e(x)+'</th>' for x in head)+'</tr></thead><tbody>'+(''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in row)+'</tr>' for row in body) or '<tr><td colspan="20" class="empty">Ainda não há registros.</td></tr>')+'</tbody></table></div>'
def empty(title,text): return '<div class="empty-state"><span class="empty-symbol">◈</span><h2>'+e(title)+'</h2><p>'+e(text)+'</p></div>'
def details(title,body): return '<details><summary>'+e(title)+'</summary><div class="detail-body">'+body+'</div></details>'
def metric(value,label,small=''): return '<div class="metric"><span>'+e(label)+'</span><strong>'+e(value)+'</strong><small>'+e(small)+'</small></div>'

def layout(ctx,title,body):
    user=ctx.get('user');comp=ctx.get('c');rr=ctx.get('roles',set());tab=ctx.get('tab','overview')
    nav=''
    if ctx.get('public'):
        nav=link('/public','⌂  Campeonatos públicos','nav-item')
        if comp:
            pub=public_config(comp);cid=comp['id']
            items=[('overview','Início')]
            if pub['roster']: items.append(('participants','Oradores'))
            if pub['team']: items.append(('team','Equipe Speaker'))
            if pub['rounds']: items.append(('rooms','Salas e rodadas'))
            if pub['rankings']: items.append(('rankings','Classificação e tops'))
            if pub['break']: items.append(('break','Break'))
            if pub['champion']: items.append(('champion','Campeão'))
            nav+=''.join(link(f'/public/{cid}?tab={key}',label,'nav-item '+('active' if tab==key else '')) for key,label in items)
        nav+=link('/login','Acesso da organização','nav-item')
    elif user:
        nav+=link('/','⌂  Campeonatos','nav-item '+('active' if not comp else ''))
        if comp:
            items=[('overview','Visão geral'),('participants','Oradores'),('team','Equipe')]
            if rr=={'equity'}: items=[('equity','Impedimentos'),('participants','Oradores'),('team','Juízes')]
            else:
                items += [('rooms','Salas e rodadas')]
                if rr&{'SM','NSM'}: items += [('scores','Minhas avaliações')]
                items += [('rankings','Classificação'),('finals','Eliminatórias'),('audit','Histórico')]
                if 'organizer' in rr: items += [('publication','Publicação'),('emails','E-mails'),('settings','Configurações')]
            nav+='<span class="nav-label">'+e(comp['name'])+'</span>'
            nav+=''.join(link(f"/t/{comp['id']}?tab={key}",label,'nav-item '+('active' if tab==key else '')) for key,label in items)
        if user['moderator']: nav+='<span class="nav-label">Plataforma</span>'+link('/admin','Moderação global','nav-item')
    account=(f'<div class="account"><div class="avatar">{e(user["name"][:1])}</div><div><b>{e(user["name"])}</b><small>{e(user["society"])}</small></div></div>'+form(ctx,'/logout','','Sair')) if user else '<p class="sidebar-note">Gestão de Public Speaking.<br>Do primeiro discurso à final.</p>'
    notice='<div class="notice">'+e(ctx['notice'])+'</div>' if ctx.get('notice') else ''
    badge='Consulta pública · sem cadastro' if ctx.get('public') else (' · '.join({'organizer':'Organização','equity':'Equidade','advisor':'Advisor'}.get(x,x) for x in sorted(rr)) if comp else 'Gestão de Public Speaking')
    access_label='● Acesso público' if ctx.get('public') else '● Link privado · campeonato' if ctx.get('private_c') else '● Acesso restrito'
    return '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#332848"><title>'+e(title)+' · Tribuna</title><link rel="stylesheet" href="/static/style.css"></head><body><a href="#content" class="skip">Pular para o conteúdo</a><aside class="sidebar"><a class="brand" href="/"><span class="brand-icon">T</span>tribuna<span class="brand-dot">.</span></a><div class="sidebar-tag">PUBLIC SPEAKING</div><nav>'+nav+'</nav><footer>'+account+'</footer></aside><main id="content"><div class="topbar"><span>'+e(badge)+'</span><span class="private-label">'+e(access_label)+'</span></div><div class="page-heading"><div><span class="eyebrow">TRIBUNA / '+e(comp['name'] if comp else 'SEU ESPAÇO')+'</span><h1>'+e(title)+'</h1></div></div>'+notice+body+'<footer class="page-footer">Tribuna · Cada discurso conta.</footer></main><script src="/static/app.js" defer></script></body></html>'

def auth_page(ctx,kind,token=''):
    if kind=='login':
        body=field('username','Usuário ou e-mail',extra='autocomplete="username"')+field('password','Senha',type='password',extra='autocomplete="current-password"')
        panel=form(ctx,'/login',body,'Entrar')+link('/forgot','Esqueci minha senha','text-link')
        title='Bem-vindo à sua tribuna.';sub='Entre para acessar os campeonatos dos quais você faz parte.'
    elif kind=='forgot':
        panel=form(ctx,'/forgot',field('email','E-mail cadastrado',type='email'),'Enviar recuperação');title='Recuperar acesso';sub='Enviaremos as instruções para o e-mail vinculado à conta.'
    elif kind=='reset':
        panel=form(ctx,'/reset',hidden('token',token)+field('password','Nova senha',type='password',extra='minlength="12" autocomplete="new-password"'),'Alterar senha');title='Uma nova senha';sub='Use pelo menos 12 caracteres.'
    else:
        panel=form(ctx,'/invite',hidden('token',token)+(('<p>Você está conectado. Aceite o convite para vincular esta conta.</p>') if ctx.get('user') else field('username','Escolha seu usuário',extra='autocomplete="username"')+field('password','Crie sua senha',type='password',extra='minlength="12" autocomplete="new-password"')),'Aceitar convite')
        title='Seu lugar na equipe';sub='O convite vincula seu acesso ao e-mail cadastrado. Se já tem uma conta, entre antes de aceitar.'
        if not ctx.get('user'): panel+=link('/login','Já tenho uma conta','text-link')
    return layout(ctx,title,'<div class="auth-grid"><div class="auth-story"><span class="pill">PALAVRAS QUE TRANSFORMAM</span><h2>O palco é dos oradores.<br>A organização fica aqui.</h2><p>Salas, avaliações e decisões, reunidas em um espaço para a sua equipe.</p><div class="abstract"><div class="orb"></div><div class="podium"></div><span>01 — 02 — 03</span></div></div>'+card(title,panel,sub)+'</div>')

def home(ctx,db):
    u=ctx['user'];comps=rows(db,'SELECT c.*,m.roles FROM competitions c JOIN memberships m ON m.c=c.id WHERE m.u=? ORDER BY c.id DESC',(u['id'],))
    body='<div class="hero"><div><span class="eyebrow">UM ESPAÇO PARA CADA CAMPEONATO</span><h2>Organize com clareza.<br>Julgue com independência.</h2><p>Escolha um campeonato para continuar de onde sua equipe parou.</p></div><div class="hero-mark">“</div></div>'
    if comps:
        body+='<div class="competition-grid">'+''.join('<a class="competition-card" href="/t/'+str(c['id'])+'"><span class="mini-logo">PS</span><h2>'+e(c['name'])+'</h2><p>'+e(' · '.join(json.loads(c['roles'])))+'</p><span class="text-link">Abrir campeonato →</span></a>' for c in comps)+'</div>'
    else: body+=empty('Nenhum campeonato vinculado','Seu acesso aparece aqui quando você aceita um convite. A moderação global não permite abrir campeonatos de outras equipes.')
    if u['organizer']:
        body+=details('Criar campeonato',form(ctx,'/create',field('name','Nome do campeonato')+'<p class="muted">Você será organizador deste campeonato. As funções de SM, NSM ou Advisor são definidas separadamente.</p>','Criar campeonato'))
    return layout(ctx,'Seus campeonatos',body)

def admin_page(ctx,db):
    soc=[(x['name'],x['name']) for x in rows(db,'SELECT name FROM societies ORDER BY name')]
    body='<div class="notice">A moderação global gerencia contas e autoriza organizadores. Ela não concede acesso aos dados dos campeonatos.</div>'
    content=field('name','Nome completo')+field('email','E-mail',type='email')+select('society','Sociedade',soc,'SDS UFBA')+select('global_role','Permissão',[('organizer','Pode criar campeonatos'),('moderator','Moderação global')])
    body+=card('Convidar responsável',form(ctx,'/admin/invite',content,'Enviar convite'))
    users=rows(db,'SELECT id,name,email,society,moderator,organizer,active FROM users ORDER BY name')
    data=[]
    for u in users:
        f=form(ctx,'/admin/permissions',hidden('user',u['id'])+check('moderator','Moderador global',u['moderator'])+check('organizer','Pode criar campeonatos',u['organizer'])+check('active','Conta ativa',u['active'])+field('reason','Justificativa'),'Atualizar')
        data.append([e(u['name']),e(u['email']),e(u['society']),pill('Moderador' if u['moderator'] else 'Organizador' if u['organizer'] else 'Membro'),details('Gerenciar',f)])
    body+=card('Contas da plataforma',table(['Nome','E-mail','Sociedade','Acesso','Ações'],data))
    body+=card('Adicionar sociedade',form(ctx,'/admin/society',field('name','Nome da sociedade'),'Adicionar'))
    return layout(ctx,'Moderação global',body)

def overview(ctx,db):
    c=ctx['c']['id']; rr=ctx['roles'];ps=rows(db,'SELECT * FROM participants WHERE c=?',(c,));team=member_list(db,c)
    counts=[one(db,'SELECT COUNT(*) AS n FROM scores WHERE c=? AND n=?',(c,n))['n'] for n in (1,2,3)]
    body='<div class="hero compact"><div><span class="eyebrow">'+e(ctx['c']['name'])+'</span><h2>Da primeira palavra<br>ao último aplauso.</h2><p>Acompanhe a preparação, o julgamento e os resultados do campeonato.</p></div><div class="hero-mark">“</div></div>'
    body+='<div class="metrics">'+metric(len(ps),'Oradores inscritos',str(sum(p['status']=='active' for p in ps))+' ativos')+metric(len(judges(db,c)),'Juízes','SM e NSM')+metric(sum(state(db,c,n)=='closed' for n in (1,2,3)),'Rodadas encerradas','de 3 classificatórias')+metric(len(team),'Membros da equipe','Acessos individuais')+'</div>'
    stages=''
    for n in (1,2,3):
        st=state(db,c,n);label={'draft':'Preparação','open':'Em avaliação','closed':'Encerrada'}[st]
        stages+='<div class="stage"><span class="stage-number">0'+str(n)+'</span><div><h3>Rodada '+str(n)+'</h3><p>'+str(counts[n-1])+' avaliações enviadas</p></div>'+pill(label,'success' if st=='closed' else '')+'</div>'
    body+=card('O caminho até o break',stages)
    notes=rows(db,'SELECT * FROM notifications WHERE c=? AND u=? ORDER BY id DESC LIMIT 15',(c,ctx['user']['id']))
    body+=card('Atualizações da equipe',''.join('<div class="notification"><small>'+dt(x['created'])+'</small><p>'+e(x['message'])+'</p></div>' for x in notes) or '<p class="muted">Nenhum aviso para você.</p>')
    return body

def participants_page(ctx,db):
    c=ctx['c']['id'];org='organizer' in ctx['roles'];ps=rows(db,'SELECT * FROM participants WHERE c=? ORDER BY name',(c,));soc=[(x['name'],x['name']) for x in rows(db,'SELECT name FROM societies ORDER BY name')]
    body=''
    if org: body+=details('Cadastrar orador',action_form(ctx,'participant','<div class="form-grid">'+field('name','Nome completo')+field('email','E-mail',type='email')+select('society','Sociedade de Debates',soc)+'</div>','Cadastrar'))
    data=[]
    for p in ps:
        actions=''
        if org:
            actions=details('Participação',action_form(ctx,'participant_status',select('status','Situação',[('active','Participante ativo'),('dns','Não participou do campeonato')],p['status'])+field('reason','Justificativa'),'Salvar',dict(p=p['id'])))
        data.append([e(p['name']),e(p['society']),e(p['email']),pill('Ativo' if p['status']=='active' else 'Não participou','success' if p['status']=='active' else 'warning'),actions])
    return body+card('Inscritos', '<input class="search" type="search" data-filter placeholder="Buscar por nome, sociedade ou e-mail" aria-label="Buscar oradores">'+table(['Nome','Sociedade','E-mail','Participação',''],data),'Ausência em uma classificatória exclui o orador da classificação geral.')

def team_page(ctx,db):
    c=ctx['c']['id'];org='organizer' in ctx['roles'];team=member_list(db,c)
    if ctx['roles']=={'equity'}: team=judges(db,c)
    body=''
    if org:
        soc=[(x['name'],x['name']) for x in rows(db,'SELECT name FROM societies ORDER BY name')]
        judge_fields=field('name','Nome completo')+field('email','E-mail para receber o link',type='email')+select('society','Sociedade',soc)+select('role','Categoria',[('SM','Speaker Master'),('NSM','Novice Speaker Master')])+field('days','Validade do link (dias)',90,type='number',extra='min="1" max="365"')
        body+=details('Cadastrar SM/NSM e enviar link privado',action_form(ctx,'judge_add','<p class="muted">Todos os juízes integram a organização deste campeonato. O link concede essas funções, sem acesso global ou a outros campeonatos. Não exige criação de senha.</p><div class="form-grid">'+judge_fields+'</div>','Cadastrar e enviar link'))
        fields=field('name','Nome completo')+field('email','E-mail',type='email')+select('society','Sociedade',soc)+select('roles','Funções (Ctrl/Cmd para selecionar mais de uma)',[('organizer','Organização'),('SM','Speaker Master'),('NSM','Novice Speaker Master'),('advisor','Advisor — somente leitura'),('equity','Equidade — acesso separado')],[],True)
        body+=details('Convidar membro com usuário e senha',action_form(ctx,'invite','<div class="form-grid">'+fields+'</div>','Enviar convite'))
        body+=details('Cadastrar outra sociedade',action_form(ctx,'society',field('name','Nome da sociedade'),'Adicionar'))
    data=[]
    for u in team:
        actions=details('Remover acesso',action_form(ctx,'member_remove',field('reason','Justificativa'),'Remover',dict(user=u['id']))) if org else ''
        if org and set(u['roles'])&{'SM','NSM'}:
            grant=one(db,'SELECT id,expires FROM judge_links WHERE c=? AND u=? AND revoked=0 AND expires>? ORDER BY id DESC LIMIT 1',(c,u['id'],now()))
            content='<p class="muted">'+('Link ativo até '+dt(grant['expires']) if grant else 'Nenhum link ativo.')+'</p>'
            content+=action_form(ctx,'judge_link',field('days','Validade em dias',90,type='number',extra='min="1" max="365"')+field('reason','Justificativa'),'Gerar novo link e enviar por e-mail',dict(user=u['id']))
            if grant: content+=action_form(ctx,'judge_revoke',field('reason','Motivo da revogação'),'Revogar link e sessões',dict(user=u['id']))
            actions=details('Link privado',content)+actions
        data.append([e(u['name']),e(u['society']),e(u['email']),' '.join(pill(x) for x in u['roles']),actions])
    body+=card('Equipe do campeonato',table(['Nome','Sociedade','E-mail','Função',''],data))
    if org:
        inv=rows(db,'SELECT email,name,roles,expires FROM invites WHERE c=? AND used=0 ORDER BY id DESC',(c,))
        body+=details('Convites pendentes',table(['Nome','E-mail','Funções','Validade'],[[e(i['name']),e(i['email']),e(' · '.join(json.loads(i['roles']))),dt(i['expires'])] for i in inv]))
    return body

def room_card(ctx,db,rid):
    c=ctx['c']['id'];rr=ctx['roles'];org='organizer' in rr;r=room_info(db,c,rid);n=r['n'];members={j['id']:j for j in member_list(db,c)}
    panel='<div class="panel-names">'+''.join(pill(members[j]['name']+(' · Presidente' if j==r['chair'] else '')) for j in r['panel'])+'</div>' if r['panel'] else '<p class="warning-text">Mesa ainda não definida.</p>'
    warnings=conflict_warnings(db,c,rid)
    panel+=''.join('<div class="warning-text">⚑ '+e(x['message'])+'</div>' for x in warnings)
    data=[]
    for p in r['people']:
        extras='';sp=speech(db,c,p['id'],n) if n<=3 else None
        if sp and sp['url']: extras+=link(sp['url'],'Abrir vídeo','text-link')
        if org and n<=3:
            fields=field('url','Link do vídeo',sp['url'],type='url',required=False)+field('seconds','Duração em segundos',sp['seconds'] or '',type='number',required=False,extra='min="0"')
            if ctx['c']['config']['penalty_mode']=='manual': fields+=field('penalty','Desconto na média',number(Fraction(sp['penalty'],100)).replace(',','.'),type='number',extra='min="0" step="0.01"')
            fields+=check('absent','Não apresentou nesta rodada',sp['absent'])+field('reason','Justificativa do registro ou alteração')
            extras+=details('Vídeo, tempo e ausência',action_form(ctx,'speech',fields,'Salvar',dict(p=p['id'],round=n)))
        if org:
            opts=[(x['id'],x['name']) for x in rows(db,'SELECT id,name FROM rooms WHERE c=? AND n=? ORDER BY id',(c,n))]
            extras+=details('Mover orador',action_form(ctx,'move',select('room','Sala de destino',opts,rid)+field('position','Ordem na sala',p['position'],type='number',extra='min="1"')+field('reason','Justificativa'),'Mover',dict(p=p['id'])))
        status=pill('Ausente','warning') if sp and sp['absent'] else e(p['society'])
        data.append([e(p['position']),e(p['name']),status,extras])
    content=panel+table(['Ordem','Orador','Sociedade / situação',''],data)
    if org:
        opts=[(j['id'],j['name']+' · '+('/'.join(j['roles']))) for j in judges(db,c)]
        body=select('judges','Juízes da mesa (Ctrl/Cmd para seleção múltipla)',opts,r['panel'],True)+select('chair','Presidente',opts,r['chair'])
        if n>3: body+=field('judge_count','Quantidade de juízes',len(r['panel']) or json.loads(ctx['c']['break_spec'] or '{}').get('judge_count',3),type='number',extra='min="1" max="15"')
        body+=field('reason','Justificativa da alocação')
        content+=details('Definir ou alterar mesa',action_form(ctx,'panel',body,'Salvar mesa',dict(room=rid)))
    if n>3:
        result=json.loads(r['result']) if r['result'] else []
        if result:
            content+='<div class="result-box"><span class="eyebrow">'+('CAMPEÃO' if n==5 else 'CLASSIFICADOS')+'</span><h3>'+e(', '.join(p['name'] for p in r['people'] if p['id'] in result))+'</h3></div>'
        if ctx['user']['id']==r['chair'] and rr&{'SM','NSM'}:
            fields=select('winners','Campeão' if n==5 else f"Escolha {r['advance']} classificados",[(p['id'],p['name']) for p in r['people']],result,True)
            if result: fields+=field('reason','Justificativa da correção')
            content+=details('Registrar decisão coletiva',action_form(ctx,'decision',fields,'Confirmar resultado',dict(room=rid)))
        if org and not r['result']:
            reserves=json.loads(ctx['c']['break_spec'] or '{}').get('reserves',[])
            opts=[(p['id'],p['name']) for p in rows(db,'SELECT id,name FROM participants WHERE c=? ORDER BY name',(c,)) if p['id'] in reserves]
            if opts: content+=details('Convocar reserva',action_form(ctx,'reserve',select('p','Substituir',[(p['id'],p['name']) for p in r['people']])+select('replacement','Reserva',opts)+field('reason','Justificativa'),'Convocar',dict(room=rid)))
    return card(r['name'],content,('Rodada '+str(n)) if n<=3 else ('Classificam '+str(r['advance']) if n==4 else 'Decisão coletiva da mesa'))

def round_controls(ctx,db,n):
    c=ctx['c']['id'];st=state(db,c,n)
    if 'organizer' not in ctx['roles']: return ''
    target='closed' if st=='open' else 'open'
    label={'draft':'Fechar salas e abrir avaliações','open':'Encerrar rodada','closed':'Reabrir rodada'}[st]
    return details(label,action_form(ctx,'round_state',field('reason','Registro / justificativa'),label,dict(round=n,state=target)))

def rooms_page(ctx,db,finals=False):
    c=ctx['c']['id'];org='organizer' in ctx['roles'];ns=[x['n'] for x in rows(db,'SELECT n FROM rounds WHERE c=? AND n>3 ORDER BY n',(c,))] if finals else [1,2,3]
    body=''
    if finals and not ns:
        return empty('O próximo palco vem depois do break','Encerre as três classificatórias e gere o break na aba Classificação.')
    for n in ns:
        st=state(db,c,n)
        body+='<div class="section-title"><h2>'+('Rodada '+str(n) if n<=3 else 'Semifinais' if n==4 else 'Final de PS')+'</h2>'+pill({'draft':'Preparação','open':'Em andamento','closed':'Encerrada'}[st])+'</div>'
        if org and not finals and st=='draft': body+=details('Sortear oradores e juízes',action_form(ctx,'draw_rooms',field('count','Número de salas',3,type='number',extra='min="1" max="100"')+field('reason','Justificativa se estiver refazendo um sorteio',required=False),'Sortear',dict(round=n)))
        body+=round_controls(ctx,db,n)
        rms=rows(db,'SELECT id FROM rooms WHERE c=? AND n=? ORDER BY id',(c,n))
        body+=''.join(room_card(ctx,db,r['id']) for r in rms) or '<p class="muted">As salas desta rodada ainda não foram geradas.</p>'
    return body

def scores_page(ctx,db):
    c=ctx['c']['id'];uid=ctx['user']['id'];rr=ctx['roles']
    if not rr&{'SM','NSM'}: raise Problem('Somente juízes têm área de avaliações.',403)
    body='<div class="notice">As notas do colega ficam ocultas até o encerramento das três classificatórias. Depois de enviar, qualquer correção exige justificativa.</div>'
    own=[];subs=[]
    for r_ in rows(db,'SELECT id FROM rooms WHERE c=? AND n<=3 ORDER BY n,id',(c,)):
        r=room_info(db,c,r_['id']);n=r['n']
        for p in r['people']:
            if p['status']!='active' or speech(db,c,p['id'],n)['absent']: continue
            all_=all_scores(db,c,p['id'],n)
            for j in r['panel']:
                sc=next((x for x in all_ if x['j']==j),None)
                if j!=uid and sc: continue
                if j!=uid and state(db,c,n)!='open': continue
                is_own=j==uid
                name=one(db,'SELECT name FROM users WHERE id=?',(j,))['name']
                fields='<div class="score-grid">'+''.join(field('criterion'+str(i),crit,sc['values'][i] if sc else '',type='number',extra='min="0" max="15" step="1" data-score') for i,crit in enumerate(CRITERIA))+'</div><div class="score-total">Soma: <output data-total>'+str(sc['total'] if sc else 0)+'</output> / 75</div>'
                if sc or not is_own: fields+=area('reason','Justificativa da '+('correção' if sc else 'substituição'))
                content=(link(speech(db,c,p['id'],n)['url'],'Abrir vídeo','text-link') if speech(db,c,p['id'],n)['url'] else '')
                if state(db,c,n)=='open': content+=action_form(ctx,'score',fields,'Corrigir avaliação' if sc else 'Enviar avaliação',dict(p=p['id'],round=n,judge=j,version=sc['version'] if sc else 0))
                elif sc: content+=table(CRITERIA,[[str(v) for v in sc['values']]])+'<p class="muted">Rodada encerrada. Correções exigem reabertura pela organização.</p>'
                else: content+='<p class="muted">Aguarde a abertura da rodada.</p>'
                if is_own and len(all_)==2 and abs(all_[0]['total']-all_[1]['total'])>=4:
                    waiver=one(db,'SELECT * FROM waivers WHERE c=? AND p=? AND n=?',(c,p['id'],n));valid=waiver and waiver['signature']==score_signature(all_)
                    content+='<div class="notice warning">'+('Divergência mantida com justificativa.' if valid else 'Avaliação exige revisão. Você pode corrigir sua nota ou justificar a manutenção da divergência.')+'</div>'
                    if not valid and state(db,c,n)=='open': content+=details('Manter divergência',action_form(ctx,'waiver',area('reason','Justificativa'),'Registrar justificativa',dict(p=p['id'],round=n)))
                title=p['name']+' · R'+str(n)
                item=card(title,content,r['name']+' · '+('Sua avaliação' if is_own else 'Em nome de '+name))
                (own if is_own else subs).append(item)
    body+=''.join(own) or empty('Você ainda não tem avaliações','A organização precisa alocar você em uma mesa.')
    if subs: body+=details('Lançar avaliação pendente em nome de outro juiz','<p class="muted">Use somente em uma substituição necessária. Sua identidade e justificativa serão registradas.</p>'+''.join(subs))
    return body

def rankings_page(ctx,db):
    c=ctx['c']['id'];org='organizer' in ctx['roles'];is_closed=closed(db,c)
    early_reader=org and not ctx['roles']&{'SM','NSM'}
    if not is_closed and not early_reader: return empty('Resultados ainda em sigilo','Mesmo integrando a organização, juízes só veem a classificação e as avaliações dos colegas quando as três classificatórias estiverem encerradas.')
    ranked,excluded,pending=ranking(db,c);body=''
    if not is_closed: body+='<div class="notice">Prévia exclusiva da organização. Somente oradores com as seis avaliações entram nesta lista.</div>'
    if pending:
        body+='<div class="notice warning">Empate após Golden, Silver e Bronze: '+e('; '.join(', '.join(g['names']) for g in pending))+'. A ordem entre esses nomes ainda não foi decidida.</div>'
        if org and is_closed: body+=action_form(ctx,'lottery','','Sortear desempates e registrar resultado')
    tied={p for group in pending for p in group['ids']}
    data=[[e(i+1) if p['id'] not in tied else pill('Empate'),'<b>'+e(p['name'])+'</b><small>'+e(p['society'])+'</small>',*[number(v) for v in p['rounds']],'<strong class="accent">'+number(p['mean'])+'</strong>',number(p['best'][0]),number(p['best'][1]),number(p['best'][2])] for i,p in enumerate(ranked)]
    body+=card('Classificação geral',table(['Pos.','Orador','R1','R2','R3','Média','Golden','Silver','Bronze'],data),'Média das três rodadas, já descontadas as penalidades. Cálculo exato, sem arredondamento para desempatar.')
    if excluded: body+=details('Fora da classificação / avaliações incompletas',table(['Orador','Sociedade','Situação'],[[e(p['name']),e(p['society']),e('Não participou' if p['status']=='dns' else 'Rodada ausente ou avaliação pendente')] for p in excluded]))
    cfg=ctx['c']['config']
    if org and is_closed:
        body+=details('Montar top de melhores discursos',action_form(ctx,'top_options',check('repeat','Permitir que o mesmo orador apareça mais de uma vez',cfg['repeat_speakers'])+field('top_size','Quantidade no top',cfg['top_size'],type='number',extra='min="1"'),'Montar top'))
    speeches=[]
    for p in ranked:
        indexes=range(3) if cfg['repeat_speakers'] else [max(range(3),key=lambda i:p['rounds'][i])]
        for i in indexes:
            mx=max(s['total'] for s in all_scores(db,c,p['id'],i+1))
            sp=speech(db,c,p['id'],i+1)
            key=(p['rounds'][i],*(p['best'] if cfg['speech_tie']=='golden' else [Fraction(mx)-Fraction(sp['penalty'],100),p['best'][1]]))
            speeches.append(dict(person=p,round=i+1,value=p['rounds'][i],key=key))
    speeches.sort(key=lambda x:x['key'],reverse=True)
    body+=card('Melhores discursos',table(['Pos.','Orador','Rodada','Média do discurso'],[[e(1+next(i for i,x in enumerate(speeches) if x['key']==s['key'])),e(s['person']['name']),'R'+str(s['round']),number(s['value'])] for s in speeches[:cfg['top_size']]]),'Empates remanescentes compartilham a colocação neste ranking. '+('O orador pode aparecer em mais de uma rodada.' if cfg['repeat_speakers'] else 'Somente o melhor discurso de cada orador.'))
    criteria_content=''
    for i,label in enumerate(CRITERIA):
        entries=[]
        for p in ranked:
            vals=[s['values'][i] for n in (1,2,3) for s in all_scores(db,c,p['id'],n)]
            entries.append((Fraction(sum(vals),6),p['name']))
        entries.sort(key=lambda x:x[0],reverse=True)
        criteria_content+=details(label,table(['Pos.','Orador','Média / 15'],[[str(1+next(k for k,x in enumerate(entries) if x[0]==v)),e(name),number(v)] for v,name in entries]))
    body+=card('Melhores por critério',criteria_content,'Média das seis avaliações, sem descontar a penalidade de tempo dos critérios individuais.')
    if org and is_closed and not ctx['c']['break_spec'] and ranked:
        fields=field('size','Quantos passam para as eliminatórias?',min(12,len(ranked)),type='number',extra=f'min="1" max="{len(ranked)}"')+select('phase','Primeira fase',[('semi','Duas semifinais'),('final','Somente final')])+field('advance','Quantos avançam de cada semifinal?',3,type='number',extra='min="1"')+field('judge_count','Quantos juízes por mesa nas eliminatórias?',3,type='number',extra='min="1" max="15"')
        body+=card('Gerar o break',action_form(ctx,'break','<div class="form-grid">'+fields+'</div>','Gerar eliminatórias'),'Semifinais recebem metade dos classificados em cada sala, com distribuição equilibrada por colocação. O restante forma a lista de reservas.')
    # Score visibility is enforced here, not in CSS or JavaScript.
    if org or is_closed:
        report=[]
        for p in rows(db,'SELECT id,name FROM participants WHERE c=? ORDER BY name',(c,)):
            for n in (1,2,3):
                scs=all_scores(db,c,p['id'],n)
                for s in scs:
                    j=one(db,'SELECT name FROM users WHERE id=?',(s['j'],))
                    report.append([e(p['name']),str(n),e(j['name']),*[str(v) for v in s['values']],str(s['total'])])
        body+=details('Avaliações por juiz',table(['Orador','R','Juiz',*CRITERIA,'Soma'],report))
        if org and not is_closed:
            pending_forms=''
            for p in rows(db,'SELECT id,name FROM participants WHERE c=?',(c,)):
                for n in (1,2,3):
                    scs=all_scores(db,c,p['id'],n)
                    if len(scs)!=2 or abs(scs[0]['total']-scs[1]['total'])<4: continue
                    w=one(db,'SELECT signature FROM waivers WHERE c=? AND p=? AND n=?',(c,p['id'],n))
                    if not w or w['signature']!=score_signature(scs): pending_forms+=details(p['name']+' · R'+str(n),action_form(ctx,'waiver',area('reason','Justificativa'),'Manter divergência',dict(p=p['id'],round=n)))
            if pending_forms: body+=card('Divergências pendentes',pending_forms)
    return body

def equity_page(ctx,db):
    c=ctx['c']['id']
    if ctx['roles']!={'equity'}: raise Problem('Área exclusiva da equidade.',403)
    js_=judges(db,c);ps=rows(db,'SELECT id,name FROM participants WHERE c=? ORDER BY name',(c,));jn={j['id']:j['name'] for j in js_};pn={p['id']:p['name'] for p in ps}
    body='<div class="notice">Somente a equidade visualiza os motivos. A organização recebe apenas o aviso de conflito na sala.</div>'
    for kind,label,targets in [('speaker','Juiz × orador',[(p['id'],p['name']) for p in ps]),('judge','Juiz × juiz',[(j['id'],j['name']) for j in js_])]:
        fields=select('judge','Juiz',[(j['id'],j['name']) for j in js_])+select('target','Orador' if kind=='speaker' else 'Outro juiz',targets)+area('reason','Motivo confidencial')
        body+=details('Registrar impedimento: '+label,action_form(ctx,'conflict',fields,'Registrar',dict(kind=kind)))
    conflicts=rows(db,'SELECT * FROM conflicts WHERE c=? ORDER BY id DESC',(c,))
    data=[]
    for f in conflicts:
        broken=rows(db,'SELECT r.name,r.n FROM breaches b JOIN rooms r ON r.id=b.room WHERE b.conflict=? AND b.active=1',(f['id'],))
        act=details('Retirar',action_form(ctx,'conflict_remove',field('reason','Justificativa'),'Retirar impedimento',dict(id=f['id']))) if f['active'] else ''
        data.append([str(f['id']),e(jn.get(f['judge'],'Membro removido')),e((pn if f['kind']=='speaker' else jn).get(f['target'],'Membro removido')),e(f['reason']),pill('Ativo' if f['active'] else 'Retirado'),'<br>'.join(e(b['name']+' · R'+str(b['n'])) for b in broken) or '—',act])
    body+=card('Impedimentos',table(['Nº','Juiz','Pessoa impedida','Motivo confidencial','Estado','Quebras',''],data))
    notes=rows(db,'SELECT * FROM notifications WHERE c=? AND u=? ORDER BY id DESC LIMIT 30',(c,ctx['user']['id']))
    body+=card('Avisos à equidade',''.join('<div class="notification"><small>'+dt(x['created'])+'</small><p>'+e(x['message'])+'</p></div>' for x in notes) or '<p class="muted">Nenhum aviso registrado.</p>')
    return body

def audit_page(ctx,db):
    c=ctx['c']['id'];rr=ctx['roles'];org='organizer' in rr
    if rr=={'equity'}: raise Problem('A equidade não acessa o histórico de pontuação.',403)
    events=rows(db,"SELECT a.*,u.name AS actor_name FROM audit a LEFT JOIN users u ON u.id=a.actor WHERE a.c=? AND a.visibility!='equity' ORDER BY a.id DESC LIMIT 500",(c,))
    early_reader=org and not rr&{'SM','NSM'}
    events=[a for a in events if a['visibility']!='scores' or early_reader or closed(db,c)]
    data=[]
    for a in events:
        content='<p><b>Antes</b></p><pre>'+e(json.dumps(json.loads(a['before_json']),ensure_ascii=False,indent=2))+'</pre><p><b>Depois</b></p><pre>'+e(json.dumps(json.loads(a['after_json']),ensure_ascii=False,indent=2))+'</pre><small>Registro '+str(a['id'])+' · '+e(a['digest'])+'</small>'
        data.append([e(dt(a['created'])),e(a['actor_name'] or 'Sistema'),e(a['action']),e(a['object']),e(a['reason'] or '—'),details('Ver alteração',content)])
    return card('Registro de alterações',table(['Quando','Autor','Ação','Referência','Justificativa','Valores'],data),'Últimos 500 registros. Antes e depois são preservados; não há edição ou exclusão pelo sistema.')

def emails_page(ctx,db):
    if 'organizer' not in ctx['roles']: raise Problem('Somente a organização.',403)
    c=ctx['c']['id'];cfg=ctx['c']['config'];fields=field('mail_subject','Assunto',cfg['mail_subject'])+area('mail_body','Mensagem',cfg['mail_body'])+area('links','Links importantes',cfg['links'],False)+field('reply_to','E-mail para respostas',cfg['reply_to'],type='email',required=False)
    help_='<p class="muted">Personalize com {nome}, {campeonato} e {links}. Cada destinatário recebe uma mensagem individual. O remetente é o endereço autenticado na configuração de envio; as respostas podem ir para o e-mail do campeonato.</p>'
    body=card('Mensagem aos inscritos',help_+action_form(ctx,'mail_save',fields,'Salvar modelo'))
    send=''.join(hidden(k,cfg[k]) for k in ['mail_subject','mail_body','links','reply_to'])+check('confirm','Confirmo o envio do modelo salvo para todos os inscritos')
    body+=details('Enviar modelo salvo',action_form(ctx,'mail_send',send,'Enviar aos inscritos'))
    if not os.environ.get('SMTP_HOST'): body+='<div class="notice warning">O serviço de e-mail ainda não foi configurado. As mensagens ficam na fila e não são marcadas como enviadas.</div>'
    messages=rows(db,'SELECT recipient,subject,status,attempts,error FROM outbox WHERE c=? ORDER BY id DESC LIMIT 100',(c,))
    labels={'pending':'Na fila','sending':'Enviando','sent':'Enviado','retry':'Nova tentativa','failed':'Falhou'}
    body+=card('Fila de envio',table(['Destinatário','Assunto','Estado','Tentativas','Erro'],[[e(m['recipient']),e(m['subject']),pill(labels.get(m['status'],m['status'])),str(m['attempts']),e(m['error'])] for m in messages]))
    return body

def settings_page(ctx,db):
    if 'organizer' not in ctx['roles']: raise Problem('Somente a organização.',403)
    cfg=ctx['c']['config'];fields=select('penalty_mode','Penalidade de tempo',[('manual','Desconto manual na média'),('automatic','Calcular pela duração')],cfg['penalty_mode'])+field('limit_seconds','Tempo limite (segundos)',cfg['limit_seconds'],type='number')+field('tolerance_seconds','Tolerância (segundos)',cfg['tolerance_seconds'],type='number')+field('rate_cents','Desconto por segundo em centésimos (20 = 0,20 ponto)',cfg['rate_cents'],type='number')+select('speech_tie','Desempate dos melhores discursos',[('golden','Golden / Silver / Bronze'),('individual','Maior nota individual / segunda melhor média')],cfg['speech_tie'])+field('top_size','Tamanho inicial do top',cfg['top_size'],type='number')
    return card('Regras deste campeonato',action_form(ctx,'settings','<div class="form-grid">'+fields+'</div>','Salvar regras'),'Cinco critérios, notas inteiras de 0 a 15. As regras de pontuação ficam bloqueadas após a primeira avaliação.')

def publication_page(ctx,db):
    if 'organizer' not in ctx['roles']: raise Problem('Somente a organização.',403)
    pub=public_config(ctx['c']);c=ctx['c']['id']
    body='<div class="notice">Oradores e público acessam sem conta. Somente os itens liberados abaixo aparecem na página pública. E-mails, links de juiz, vídeos, cédulas individuais, histórico e impedimentos nunca são publicados por esta tela.</div>'
    fields=check('enabled','Ativar página pública e listar este campeonato',pub['enabled'])+area('intro','Apresentação pública',pub['intro'],False)+check('roster','Publicar nomes e sociedades dos oradores',pub['roster'])+check('team','Publicar equipe Speaker (SM, NSM e Advisor)',pub['team'])
    opts=[(r['n'],'Rodada '+str(r['n']) if r['n']<=3 else 'Semifinais' if r['n']==4 else 'Final de PS') for r in rows(db,'SELECT n FROM rounds WHERE c=? ORDER BY n',(c,))]
    fields+='<label>Publicar salas e mesas destas rodadas (opcional)<select name="public_rounds" multiple size="5">'+''.join('<option value="'+str(n)+'" '+('selected' if n in pub['rounds'] else '')+'>'+e(name)+'</option>' for n,name in opts)+'</select></label>'
    fields+=check('rankings','Publicar classificação e tops após as três classificatórias',pub['rankings'])+check('break','Publicar break',pub['break'])+check('champion','Publicar campeão',pub['champion'])+field('reason','Registro / justificativa da publicação')
    body+=card('Controle de publicação',action_form(ctx,'publish',fields,'Salvar publicação'))
    if pub['enabled']: body+=link(f'/public/{c}','Abrir página pública','button-link')
    return body

def judge_entry(ctx,db,grant,token):
    comp=competition(db,grant['c'])
    content='<p>Você vai acessar <b>'+e(comp['name'])+'</b> como <b>'+e(grant['name'])+'</b>, integrante da equipe Speaker e da organização.</p><p class="muted">Este link é sua chave de acesso. Não o compartilhe. Não é necessário criar senha.</p>'
    content+=form(ctx,'/judge',hidden('token',token),'Entrar no campeonato')
    return layout(ctx,'Acesso da equipe Speaker',card('Seu link privado',content))

def public_context(ctx,comp=None,tab='overview'):
    return dict(user=None,csrf=ctx.get('csrf',''),notice='',public=True,c=comp,roles=set(),tab=tab)

def public_home(ctx,db):
    comps=[]
    for r in rows(db,'SELECT id FROM competitions ORDER BY id DESC'):
        comp=competition(db,r['id'])
        if public_config(comp)['enabled']: comps.append(comp)
    body='<div class="hero"><div><span class="eyebrow">PUBLIC SPEAKING</span><h2>Cada discurso,<br>um novo palco.</h2><p>Acompanhe os campeonatos e as informações liberadas pelas equipes organizadoras. Sem cadastro ou senha.</p></div><div class="hero-mark">“</div></div>'
    body+='<div class="competition-grid">'+''.join('<a class="competition-card" href="/public/'+str(c['id'])+'"><span class="mini-logo">PS</span><h2>'+e(c['name'])+'</h2><span class="text-link">Acompanhar campeonato →</span></a>' for c in comps)+'</div>' if comps else empty('Nenhum campeonato publicado','As equipes organizadoras liberarão as páginas dos seus eventos aqui.')
    return layout(public_context(ctx),'Campeonatos',body)

def public_tournament(ctx,db,c,tab):
    comp=competition(db,c);pub=public_config(comp)
    if not pub['enabled']: raise Problem('Página pública não disponível.',404)
    public_ctx=public_context(ctx,comp,tab)
    allowed={'overview':True,'participants':pub['roster'],'team':pub['team'],'rooms':bool(pub['rounds']),'rankings':pub['rankings'] and closed(db,c),'break':pub['break'] and bool(comp['break_spec']),'champion':pub['champion']}
    if not allowed.get(tab,False): raise Problem('Esta informação ainda não foi publicada.',404)
    title={'overview':comp['name'],'participants':'Oradores','team':'Equipe Speaker','rooms':'Salas e rodadas','rankings':'Classificação e tops','break':'Break','champion':'Campeão'}[tab]
    body=''
    if tab=='overview':
        body='<div class="hero"><div><span class="eyebrow">CAMPEONATO DE PUBLIC SPEAKING</span><h2>'+e(comp['name'])+'</h2><p>Acompanhe as informações oficiais liberadas pela organização.</p></div><div class="hero-mark">“</div></div>'
        body+=card('Boas-vindas','<p class="public-intro">'+e(pub['intro'] or 'As informações do campeonato serão publicadas neste espaço.')+'</p>')
        body+=card('Acompanhe o campeonato','<div class="public-links">'+''.join(link(f'/public/{c}?tab={key}',{'participants':'Oradores','team':'Equipe Speaker','rooms':'Salas e rodadas','rankings':'Classificação e tops','break':'Break','champion':'Campeão'}[key],'button-link') for key,show in allowed.items() if show and key!='overview')+'</div>')
    elif tab=='participants':
        ps=rows(db,'SELECT name,society FROM participants WHERE c=? ORDER BY name',(c,))
        body=card('Oradores inscritos',table(['Nome','Sociedade'],[[e(p['name']),e(p['society'])] for p in ps]))
    elif tab=='team':
        team=[u for u in member_list(db,c) if set(u['roles'])&{'SM','NSM','advisor'}]
        body=card('Equipe Speaker',table(['Nome','Sociedade','Categoria'],[[e(u['name']),e(u['society']),e(' · '.join(x for x in u['roles'] if x in ('SM','NSM','advisor')))] for u in team]))
    elif tab=='rooms':
        names={u['id']:u['name'] for u in member_list(db,c)}
        for n in pub['rounds']:
            if not one(db,"SELECT 1 FROM rounds WHERE c=? AND n=? AND state!='draft'",(c,n)): continue
            body+='<div class="section-title"><h2>'+e('Rodada '+str(n) if n<=3 else 'Semifinais' if n==4 else 'Final de PS')+'</h2></div>'
            for r_ in rows(db,'SELECT id FROM rooms WHERE c=? AND n=? ORDER BY id',(c,n)):
                r=room_info(db,c,r_['id'])
                panel='<p class="muted">Mesa: '+e(' · '.join(names.get(j,'Juiz')+(' (Presidente)' if j==r['chair'] else '') for j in r['panel']))+'</p>'
                body+=card(r['name'],panel+table(['Ordem','Orador','Sociedade'],[[e(p['position']),e(p['name']),e(p['society'])] for p in r['people']]))
    elif tab=='rankings':
        ranked,_,pending=ranking(db,c);tied={p for g in pending for p in g['ids']};cfg=comp['config']
        body=card('Classificação geral',table(['Pos.','Orador','Sociedade','R1','R2','R3','Média'],[[pill('Empate') if p['id'] in tied else str(i+1),e(p['name']),e(p['society']),*[number(v) for v in p['rounds']],number(p['mean'])] for i,p in enumerate(ranked)]))
        speeches=[]
        for p in ranked:
            indexes=range(3) if cfg['repeat_speakers'] else [max(range(3),key=lambda i:p['rounds'][i])]
            for i in indexes:
                sc=all_scores(db,c,p['id'],i+1);sp=speech(db,c,p['id'],i+1)
                key=(p['rounds'][i],*(p['best'] if cfg['speech_tie']=='golden' else [Fraction(max(x['total'] for x in sc))-Fraction(sp['penalty'],100),p['best'][1]]))
                speeches.append(dict(name=p['name'],n=i+1,value=p['rounds'][i],key=key))
        speeches.sort(key=lambda s:s['key'],reverse=True)
        body+=card('Melhores discursos',table(['Pos.','Orador','Rodada','Média'],[[str(1+next(i for i,x in enumerate(speeches) if x['key']==s['key'])),e(s['name']),'R'+str(s['n']),number(s['value'])] for s in speeches[:cfg['top_size']]]))
        for i,label in enumerate(CRITERIA):
            values=[(Fraction(sum(s['values'][i] for n in (1,2,3) for s in all_scores(db,c,p['id'],n)),6),p['name']) for p in ranked]
            values.sort(key=lambda x:x[0],reverse=True)
            body+=details('Melhores em '+label.lower(),table(['Pos.','Orador','Média'],[[str(1+next(k for k,x in enumerate(values) if x[0]==v)),e(name),number(v)] for v,name in values]))
    elif tab=='break':
        spec=json.loads(comp['break_spec']);n=4 if spec['phase']=='semi' else 5
        for r_ in rows(db,'SELECT id FROM rooms WHERE c=? AND n=? ORDER BY id',(c,n)):
            r=room_info(db,c,r_['id']);body+=card(r['name'],table(['Orador','Sociedade'],[[e(p['name']),e(p['society'])] for p in r['people']]))
    elif tab=='champion':
        r=one(db,'SELECT result FROM rooms WHERE c=? AND n=5 AND result IS NOT NULL',(c,))
        if not r: raise Problem('O campeão ainda não foi publicado.',404)
        winner=participant(db,c,json.loads(r['result'])[0])
        body='<div class="hero"><div><span class="eyebrow">CAMPEÃO DE PUBLIC SPEAKING</span><h2>'+e(winner['name'])+'</h2><p>'+e(winner['society'])+'</p></div><div class="hero-mark">“</div></div>'
    return layout(public_ctx,title,body)

PAGES={'overview':('Visão geral',overview),'participants':('Oradores',participants_page),'team':('Equipe',team_page),'rooms':('Salas e rodadas',rooms_page),'scores':('Minhas avaliações',scores_page),'rankings':('Classificação',rankings_page),'finals':('Eliminatórias',lambda c,d:rooms_page(c,d,True)),'equity':('Equidade',equity_page),'audit':('Histórico',audit_page),'emails':('E-mails',emails_page),'settings':('Configurações',settings_page),'publication':('Publicação',publication_page)}
def tournament_page(ctx,db):
    if ctx['roles']=={'equity'} and ctx['tab'] not in ('equity','participants','team'): raise Problem('A equidade só acessa inscritos, juízes e impedimentos.',403)
    title,fn=PAGES.get(ctx['tab'],PAGES['overview'])
    return layout(ctx,title,fn(ctx,db))
