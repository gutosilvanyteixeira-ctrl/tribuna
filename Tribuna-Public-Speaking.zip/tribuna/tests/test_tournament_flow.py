from test_system import SystemTests
import unittest, json
from core import *
from domain import *

class FullFlowTests(SystemTests):
    # Reuse fixture and helpers without inheriting the base test cases into discovery.
    def test_semifinals_generate_final_automatically(self):
        self.complete(((53,54,55),(50,51,52)))
        self.act(self.org,'break',size='2',phase='semi',advance='1',judge_count='1')
        rooms=rows(self.db,'SELECT id FROM rooms WHERE c=? AND n=4 ORDER BY id',(self.c,))
        for r,j in zip(rooms,[self.j1,self.j2]):
            self.act(self.org,'panel',room=str(r['id']),judges=[str(j['id'])],chair=str(j['id']),judge_count='1',reason='Mesa')
        self.act(self.org,'round_state',round='4',state='open',reason='Início')
        for r,j in zip(rooms,[self.j1,self.j2]):
            p=room_info(self.db,self.c,r['id'])['people'][0]['id']
            self.act(j,'decision',room=str(r['id']),winners=[str(p)])
        final=one(self.db,'SELECT id FROM rooms WHERE c=? AND n=5',(self.c,))
        self.assertIsNotNone(final)
        self.assertEqual({p['id'] for p in room_info(self.db,self.c,final['id'])['people']},{self.p,self.q})
        self.act(self.org,'round_state',round='4',state='closed',reason='Concluído')
        for u in [self.org,self.j1,self.ad]: self.assertEqual(self.request(f'/t/{self.c}?tab=finals',u)['status'],200)
    def test_snake_distribution_twelve_speakers(self):
        # Seed six evaluations per speaker to test a full 12-person break independently of UI.
        self.db.execute('DELETE FROM placements');self.db.execute('DELETE FROM participants')
        ids=[]
        for i in range(12):
            pid=self.db.execute('INSERT INTO participants(c,name,email,society) VALUES (?,?,?,?)',(self.c,f'Orador {i+1:02}',f'orador{i}@example.test','SDUFRJ')).lastrowid;ids.append(pid)
            for n in (1,2,3):
                for j in [self.j1,self.j2]:
                    total=75-i;v=[total//5]*5
                    for k in range(total%5):v[k]+=1
                    self.db.execute('INSERT INTO scores VALUES (?,?,?,?,?,?,1)',(self.c,pid,n,j['id'],js(v),j['id']))
        self.db.execute("UPDATE rounds SET state='closed' WHERE c=?",(self.c,))
        self.act(self.org,'break',size='12',phase='semi',advance='3',judge_count='3')
        rs=rows(self.db,'SELECT id FROM rooms WHERE c=? AND n=4 ORDER BY id',(self.c,))
        positions=[[ids.index(p['id'])+1 for p in room_info(self.db,self.c,r['id'])['people']] for r in rs]
        self.assertEqual(positions,[[1,4,5,8,9,12],[2,3,6,7,10,11]])
    def test_role_change_does_not_remove_allocated_judge(self):
        token=secrets.token_urlsafe(32)
        self.db.execute('INSERT INTO invites(token,email,name,society,c,roles,expires) VALUES (?,?,?,?,?,?,?)',(digest(token),self.j1['email'],'Juiz','SDS UFBA',self.c,js(['equity']),now()+1000))
        with self.assertRaises(Problem):
            with transaction(self.db): consume_invite(self.db,token,{},self.j1)
        self.assertEqual(roles(self.db,self.c,self.j1['id']),{'SM','organizer'})
    def test_disabled_account_does_not_break_room_views(self):
        self.db.execute('UPDATE users SET active=0 WHERE id=?',(self.j1['id'],))
        self.assertEqual(self.request(f'/t/{self.c}?tab=rooms',self.org)['status'],200)

# Only execute newly declared tests for the derived fixture.
def load_tests(loader,tests,pattern):
    suite=unittest.TestSuite()
    for name in FullFlowTests.__dict__:
        if name.startswith('test_'): suite.addTest(FullFlowTests(name))
    return suite
