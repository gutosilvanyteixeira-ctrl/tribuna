import unittest,io,re,json
from urllib.parse import urlencode,urlsplit
import app,views,core
from core import *
from domain import *
from test_system import SystemTests

class AccessTests(SystemTests):
    def private_link(self,user=None,days=90):
        user=user or self.j1
        with transaction(self.db): create_judge_link(self.db,self.org,self.c,user['id'],days,'Emissão de teste')
        body=one(self.db,'SELECT body FROM outbox ORDER BY id DESC LIMIT 1')['body']
        return re.search(r'/judge\?token=([^\s]+)',body)[1]
    def raw_request(self,path,cookie='',method='GET',data=None):
        url=urlsplit(path);encoded=urlencode(data or {},doseq=True).encode()
        env=dict(PATH_INFO=url.path,QUERY_STRING=url.query,REQUEST_METHOD=method,HTTP_HOST=urlsplit(core.BASE_URL).netloc,REMOTE_ADDR='127.0.0.1',HTTP_COOKIE=cookie,CONTENT_TYPE='application/x-www-form-urlencoded',CONTENT_LENGTH=str(len(encoded)))
        env['wsgi.input']=io.BytesIO(encoded);r={}
        def start(status,headers):r.update(status=int(status.split()[0]),headers=dict(headers))
        r['body']=b''.join(app.application(env,start)).decode();return r
    def login_by_link(self,user=None):
        token=self.private_link(user);page=self.raw_request('/judge?token='+token)
        cookie=page['headers']['Set-Cookie'].split(';')[0];csrf=re.search(r'name="csrf" value="([^"]+)"',page['body'])[1]
        entered=self.raw_request('/judge',cookie,'POST',dict(csrf=csrf,token=token))
        self.assertEqual(entered['status'],303)
        return entered['headers']['Set-Cookie'].split(';')[0]
    def private_post(self,path,cookie,data):
        token=cookie.split('=',1)[1];session=one(self.db,'SELECT csrf FROM sessions WHERE token=?',(digest(token),))
        return self.raw_request(path,cookie,'POST',dict(data,csrf=session['csrf'],operation=secrets.token_hex(16)))
    def publish(self,**extra):
        self.act(self.org,'publish',enabled='yes',reason='Publicação oficial',**extra)
    def test_anonymous_home_public_not_login(self):
        response=self.raw_request('/');self.assertEqual(response['status'],200);self.assertIn('Campeonatos',response['body']);self.assertNotIn('Copa de teste',response['body'])
    def test_unpublished_tournament_404(self):
        self.assertEqual(self.raw_request(f'/public/{self.c}')['status'],404)
    def test_roster_public_has_no_email(self):
        self.publish(roster='yes')
        page=self.raw_request(f'/public/{self.c}?tab=participants')
        self.assertEqual(page['status'],200);self.assertIn('Orador Alfa',page['body']);self.assertNotIn('alfa@example.test',page['body'])
    def test_unreleased_page_no_access_by_direct_url(self):
        self.publish(roster='yes')
        for tab in ['rooms','rankings','break','champion','audit','scores','equity']:
            self.assertEqual(self.raw_request(f'/public/{self.c}?tab={tab}')['status'],404,tab)
    def test_cannot_publish_rankings_early(self):
        with self.assertRaises(Problem):self.publish(rankings='yes')
        self.assertFalse(public_config(competition(self.db,self.c))['enabled'])
    def test_cannot_publish_draft_rooms(self):
        with self.assertRaises(Problem):self.publish(public_rounds=['1'])
    def test_public_rooms_omit_conflicts_and_videos(self):
        self.open();self.act(self.eq,'conflict',judge=str(self.j1['id']),kind='speaker',target=str(self.p),reason='segredo de equidade')
        self.act(self.org,'speech',p=str(self.p),round='1',url='https://example.test/private-video',seconds='185',penalty='0',reason='Registro')
        self.publish(public_rounds=['1'])
        body=self.raw_request(f'/public/{self.c}?tab=rooms')['body']
        self.assertIn('Orador Alfa',body);self.assertIn('Presidente',body)
        for secret in ['example.test','segredo','Impedimento','Justificativa']:self.assertNotIn(secret,body)
    def test_public_rankings_omit_individual_scores(self):
        self.complete(((51,52,53),(50,51,52)));self.publish(rankings='yes')
        body=self.raw_request(f'/public/{self.c}?tab=rankings')['body'];self.assertIn('Orador Alfa',body)
        for secret in ['Juiz1','Juiz2','Avaliações por juiz','example.test','Histórico']:self.assertNotIn(secret,body)
    def test_reopen_hides_previously_published_rankings(self):
        self.complete(((51,52,53),(50,51,52)));self.publish(rankings='yes')
        self.act(self.org,'round_state',round='3',state='open',reason='Corrigir antes do break')
        self.assertEqual(self.raw_request(f'/public/{self.c}?tab=rankings')['status'],404)
    def test_judge_is_organizer_even_with_legacy_roles(self):
        self.assertEqual(roles(self.db,self.c,self.j1['id']),{'SM','organizer'})
        self.act(self.j1,'participant',name='Novo',email='novo@example.test',society='SDUFRJ')
        self.assertIsNotNone(one(self.db,'SELECT id FROM participants WHERE email=?',('novo@example.test',)))
    def test_link_login_without_password(self):
        cookie=self.login_by_link();page=self.raw_request(f'/t/{self.c}?tab=team',cookie)
        self.assertEqual(page['status'],200);self.assertIn('Cadastrar SM/NSM',page['body'])
    def test_link_does_not_grant_global_permissions(self):
        self.db.execute('UPDATE users SET moderator=1,organizer=1 WHERE id=?',(self.j1['id'],))
        cookie=self.login_by_link()
        self.assertEqual(self.raw_request('/admin',cookie)['status'],403)
        self.assertEqual(self.private_post('/create',cookie,dict(name='Não permitido'))['status'],403)
    def test_link_scoped_even_if_user_member_elsewhere(self):
        other=self.db.execute('INSERT INTO competitions(name,config,created_by) VALUES (?,?,?)',('Outro campeonato',js(DEFAULTS),self.org['id'])).lastrowid
        self.db.execute('INSERT INTO memberships VALUES (?,?,?)',(other,self.j1['id'],js(['SM'])))
        cookie=self.login_by_link();self.assertEqual(self.raw_request(f'/t/{other}',cookie)['status'],403)
        self.assertEqual(self.private_post(f'/t/{other}/participant',cookie,dict(name='X',email='x@example.test',society='SDUFRJ'))['status'],403)
    def test_judge_organization_still_cannot_see_early_scores(self):
        self.open();self.score(self.j1,total=55);self.score(self.j2,total=59)
        cookie=self.login_by_link()
        page=self.raw_request(f'/t/{self.c}?tab=rankings',cookie)
        self.assertIn('Resultados ainda em sigilo',page['body']);self.assertNotIn('>59<',page['body'])
        audit_page=self.raw_request(f'/t/{self.c}?tab=audit',cookie)['body'];self.assertNotIn('Nota enviada',audit_page)
    def test_link_session_revoked_immediately(self):
        cookie=self.login_by_link();self.act(self.org,'judge_revoke',user=str(self.j1['id']),reason='Link compartilhado')
        self.assertEqual(self.raw_request(f'/t/{self.c}',cookie)['status'],303)
    def test_rotation_invalidates_old_link_and_session(self):
        old=self.private_link();cookie=self.login_by_link();new=self.private_link()
        self.assertNotEqual(old,new);self.assertEqual(self.raw_request('/judge?token='+old)['status'],403)
        self.assertEqual(self.raw_request(f'/t/{self.c}',cookie)['status'],303)
    def test_expired_link_denied(self):
        token=self.private_link();self.db.execute('UPDATE judge_links SET expires=0')
        self.assertEqual(self.raw_request('/judge?token='+token)['status'],403)
    def test_private_link_no_account_invite_escalation(self):
        cookie=self.login_by_link();r=self.private_post('/invite',cookie,dict(token='not-an-invitation'))
        self.assertEqual(r['status'],403)
    def test_token_not_in_audit_or_team_page(self):
        token=self.private_link();team=self.request(f'/t/{self.c}?tab=team',self.org)['body']
        self.assertNotIn(token,team)
        for a in rows(self.db,'SELECT before_json,after_json,reason FROM audit'):self.assertNotIn(token,js(a))
        self.assertIsNotNone(one(self.db,'SELECT 1 FROM judge_links WHERE token=?',(digest(token),)))
    def test_new_judge_needs_no_account_signup(self):
        self.act(self.org,'judge_add',name='Juiz Novo',email='novo@example.test',society='SDUFRJ',role='NSM',days='90')
        u=one(self.db,'SELECT * FROM users WHERE email=?',('novo@example.test',))
        self.assertEqual(u['password'],'!link-only');self.assertEqual(roles(self.db,self.c,u['id']),{'NSM','organizer'})
        self.assertEqual(one(self.db,'SELECT COUNT(*) AS n FROM invites')['n'],0)
    def test_link_judge_can_manage_roster(self):
        cookie=self.login_by_link();r=self.private_post(f'/t/{self.c}/participant',cookie,dict(name='Novo orador',email='novo@example.test',society='SDUFRJ'))
        self.assertEqual(r['status'],303)
    def test_scope_does_not_leak_between_requests(self):
        cookie=self.login_by_link();self.raw_request(f'/t/{self.c}',cookie)
        self.assertIsNone(ACCESS_SCOPE.get());self.assertEqual(self.request('/admin',self.mod)['status'],200)

def load_tests(loader,tests,pattern):
    return unittest.TestSuite(AccessTests(name) for name in AccessTests.__dict__ if name.startswith('test_'))
