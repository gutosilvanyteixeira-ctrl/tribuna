import unittest,tempfile,pathlib,json,io,re,sqlite3
from urllib.parse import urlencode,urlsplit
import core,domain,views,app,mail_worker
from core import *
from domain import *

class SystemTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();core.DB=str(pathlib.Path(self.tmp.name)/'test.db');init();self.db=connect()
        self.mod=self.user('Gustavo',moderator=1,organizer=1)
        self.org=self.user('Organizadora',organizer=1)
        self.j1=self.user('Juiz1');self.j2=self.user('Juiz2');self.j3=self.user('Juiz3');self.eq=self.user('Equidade');self.ad=self.user('Advisor')
        self.c=self.db.execute('INSERT INTO competitions(name,config,created_by) VALUES (?,?,?)',('Copa de teste',js(DEFAULTS),self.org['id'])).lastrowid
        for u,rr in [(self.org,['organizer']),(self.j1,['SM']),(self.j2,['NSM']),(self.j3,['SM']),(self.eq,['equity']),(self.ad,['advisor'])]: self.db.execute('INSERT INTO memberships VALUES (?,?,?)',(self.c,u['id'],js(rr)))
        self.db.executemany("INSERT INTO rounds VALUES (?,?,'draft')",[(self.c,n) for n in (1,2,3)])
        self.p=self.db.execute('INSERT INTO participants(c,name,email,society) VALUES (?,?,?,?)',(self.c,'Orador Alfa','alfa@example.test','SDUFRJ')).lastrowid
        self.q=self.db.execute('INSERT INTO participants(c,name,email,society) VALUES (?,?,?,?)',(self.c,'Orador Beta','beta@example.test','SDS UFBA')).lastrowid
        for n in (1,2,3):
            rid=self.db.execute('INSERT INTO rooms(c,n,name,chair) VALUES (?,?,?,?)',(self.c,n,'Sala 1',self.j1['id'])).lastrowid
            self.db.executemany('INSERT INTO panels VALUES (?,?)',[(rid,self.j1['id']),(rid,self.j2['id'])])
            self.db.executemany('INSERT INTO placements VALUES (?,?,?,?,?)',[(self.c,n,self.p,rid,1),(self.c,n,self.q,rid,2)])
    def tearDown(self): self.db.close();self.tmp.cleanup()
    def user(self,name,moderator=0,organizer=0):
        uid=self.db.execute('INSERT INTO users(username,email,name,society,password,moderator,organizer) VALUES (?,?,?,?,?,?,?)',(name.lower(),name.lower()+'@example.test',name,'SDS UFBA',password_hash('senha-longa-teste-123'),moderator,organizer)).lastrowid
        return one(self.db,'SELECT * FROM users WHERE id=?',(uid,))
    def act(self,actor,action,**data):
        with transaction(self.db): return handle(self.db,actor,self.c,action,data)
    def open(self,n=1): self.act(self.org,'round_state',round=str(n),state='open',reason='Salas conferidas')
    def score(self,user,p=None,n=1,total=50,j=None,version=0,why=''):
        p=p or self.p;vals=[total//5]*5
        for i in range(total%5): vals[i]+=1
        self.act(user,'score',p=str(p),round=str(n),judge=str(j or user['id']),version=str(version),reason=why,**{'criterion'+str(i):str(v) for i,v in enumerate(vals)})
    def complete(self,totals=((50,50,50),(50,50,50))):
        for n in (1,2,3):
            self.open(n)
            for p,t in zip((self.p,self.q),totals):
                self.score(self.j1,p,n,t[n-1]);self.score(self.j2,p,n,t[n-1])
            self.act(self.org,'round_state',round=str(n),state='closed',reason='Concluída')
    def context(self,user,tab): return dict(user=user,csrf='token',notice='',c=competition(self.db,self.c),roles=roles(self.db,self.c,user['id']),tab=tab)
    def request(self,path='/',user=None,method='GET',data=None,csrf=True,host=None):
        raw,token=app.new_session(self.db,user['id'] if user else None)
        body=dict(data or {})
        if method=='POST':
            if csrf: body['csrf']=token
            body.setdefault('operation',secrets.token_hex(16))
        encoded=urlencode(body,doseq=True).encode();uri=urlsplit(path)
        env={'PATH_INFO':uri.path,'QUERY_STRING':uri.query,'REQUEST_METHOD':method,'HTTP_HOST':host or urlsplit(core.BASE_URL).netloc,'REMOTE_ADDR':'127.0.0.1','HTTP_COOKIE':app.COOKIE+'='+raw,'CONTENT_TYPE':'application/x-www-form-urlencoded','CONTENT_LENGTH':str(len(encoded)),'wsgi.input':io.BytesIO(encoded)}
        result={}
        def start(status,headers): result.update(status=int(status.split()[0]),headers=dict(headers))
        result['body']=b''.join(app.application(env,start)).decode()
        return result
    def test_moderator_has_no_competition_access(self):
        self.assertEqual(self.request('/t/'+str(self.c),self.mod)['status'],403)
        self.assertNotIn('Copa de teste',self.request('/',self.mod)['body'])
    def test_equity_denied_other_pages(self):
        for tab in ['overview','rooms','scores','rankings','finals','audit','emails','settings']:
            self.assertEqual(self.request(f'/t/{self.c}?tab={tab}',self.eq)['status'],403,tab)
    def test_equity_can_read_roster(self):
        for tab in ['equity','participants','team']: self.assertEqual(self.request(f'/t/{self.c}?tab={tab}',self.eq)['status'],200)
    def test_advisor_cannot_score_or_admin(self):
        self.open()
        with self.assertRaises(Problem): self.score(self.ad)
        with self.assertRaises(Problem): self.act(self.ad,'participant',name='X',email='x@example.test',society='SDS UFBA')
    def test_five_integer_criteria(self):
        self.open()
        for bad in ['1.5','16','-1','abc']:
            with self.assertRaises(Problem): self.act(self.j1,'score',p=str(self.p),round='1',judge=str(self.j1['id']),version='0',criterion0=bad,criterion1='10',criterion2='10',criterion3='10',criterion4='10')
        self.score(self.j1,total=0);self.assertEqual(all_scores(self.db,self.c,self.p,1)[0]['total'],0)
    def test_fractional_mean(self):
        self.open();self.score(self.j1,total=54);self.score(self.j2,total=53)
        self.assertEqual(result_of(self.db,self.c,self.p,1),Fraction(107,2))
    def test_substitution_requires_reason(self):
        self.open()
        with self.assertRaises(Problem): self.score(self.j3,j=self.j1['id'])
        self.score(self.j3,j=self.j1['id'],why='Juiz sem conexão')
        s=all_scores(self.db,self.c,self.p,1)[0];self.assertEqual(s['submitted_by'],self.j3['id'])
    def test_substitution_cannot_overwrite(self):
        self.open();self.score(self.j1)
        with self.assertRaises(Problem): self.score(self.j3,j=self.j1['id'],version=1,why='Tentativa')
    def test_own_edit_requires_reason_and_version(self):
        self.open();self.score(self.j1)
        with self.assertRaises(Problem): self.score(self.j1,total=51,version=1)
        with self.assertRaises(Problem): self.score(self.j1,total=51,version=0,why='Correção')
        self.score(self.j1,total=51,version=1,why='Correção justificada')
        self.assertEqual(all_scores(self.db,self.c,self.p,1)[0]['version'],2)
    def test_hidden_other_scores_in_html(self):
        self.open();self.score(self.j1,total=55);self.score(self.j2,total=59)
        page=self.request(f'/t/{self.c}?tab=scores',self.j1)
        self.assertEqual(page['status'],200);self.assertIn('Avaliação exige revisão',page['body']);self.assertNotIn('>59<',page['body'])
        ranking_page=self.request(f'/t/{self.c}?tab=rankings',self.j1)
        self.assertIn('Resultados ainda em sigilo',ranking_page['body'])
    def test_org_sees_both_scores(self):
        self.open();self.score(self.j1,total=55);self.score(self.j2,total=59)
        page=self.request(f'/t/{self.c}?tab=rankings',self.org)
        self.assertIn('>59<',page['body']);self.assertIn('>55<',page['body'])
    def test_discrepancy_waiver_invalidated_by_edit(self):
        self.open();self.score(self.j1,total=50);self.score(self.j2,total=54)
        self.score(self.j1,self.q);self.score(self.j2,self.q)
        with self.assertRaises(Problem): self.act(self.org,'round_state',round='1',state='closed',reason='Fim')
        self.act(self.j1,'waiver',p=str(self.p),round='1',reason='Diferença fundamentada')
        self.score(self.j1,total=49,version=1,why='Revisão')
        with self.assertRaises(Problem): self.act(self.org,'round_state',round='1',state='closed',reason='Fim')
        self.act(self.j2,'waiver',p=str(self.p),round='1',reason='Manter após revisão')
        self.act(self.org,'round_state',round='1',state='closed',reason='Fim')
    def test_manual_penalty(self):
        self.open();self.score(self.j1,total=54);self.score(self.j2,total=53)
        self.act(self.org,'speech',p=str(self.p),round='1',url='',seconds='200',penalty='2.20',reason='Tempo')
        self.assertEqual(result_of(self.db,self.c,self.p,1),Fraction(513,10))
    def test_automatic_penalty(self):
        cfg=dict(DEFAULTS,penalty_mode='automatic');self.db.execute('UPDATE competitions SET config=? WHERE id=?',(js(cfg),self.c));self.open()
        self.act(self.org,'speech',p=str(self.p),round='1',url='',seconds='195',reason='Cronometragem')
        self.assertEqual(speech(self.db,self.c,self.p,1)['penalty'],100)
    def test_missing_round_excludes(self):
        self.complete(((50,51,52),(50,51,52)))
        self.db.execute('UPDATE rounds SET state="open" WHERE c=? AND n=3',(self.c,))
        self.act(self.org,'speech',p=str(self.p),round='3',url='',seconds='',penalty='0',absent='yes',reason='Não apresentou')
        ranked,excluded,_=ranking(self.db,self.c);self.assertEqual([p['id'] for p in ranked],[self.q]);self.assertEqual(excluded[0]['id'],self.p)
    def test_golden_tie_break(self):
        self.complete(((58,54,53),(57,55,53)))
        ranked,_,pending=ranking(self.db,self.c);self.assertEqual(ranked[0]['id'],self.p);self.assertFalse(pending)
    def test_silver_tie_break(self):
        self.complete(((58,55,52),(58,54,53)))
        ranked,_,pending=ranking(self.db,self.c);self.assertEqual(ranked[0]['id'],self.p);self.assertFalse(pending)
    def test_draw_persisted_no_reroll(self):
        self.complete();self.act(self.org,'lottery');order=[p['id'] for p in ranking(self.db,self.c)[0]]
        self.assertEqual([p['id'] for p in ranking(self.db,self.c)[0]],order)
        with self.assertRaises(Problem): self.act(self.org,'lottery')
    def test_break_blocks_until_all_closed(self):
        with self.assertRaises(Problem): self.act(self.org,'break',size='2',phase='semi',advance='1',judge_count='3')
    def test_break_final_chair_only(self):
        self.complete(((51,52,53),(50,51,52)));self.act(self.org,'break',size='2',phase='final',advance='1',judge_count='2')
        r=one(self.db,'SELECT id FROM rooms WHERE c=? AND n=5',(self.c,))['id']
        self.act(self.org,'panel',room=str(r),judges=[str(self.j1['id']),str(self.j2['id'])],chair=str(self.j1['id']),judge_count='2',reason='Mesa definida')
        self.act(self.org,'round_state',round='5',state='open',reason='Prontos')
        with self.assertRaises(Problem): self.act(self.j2,'decision',room=str(r),winners=[str(self.p)])
        self.act(self.j1,'decision',room=str(r),winners=[str(self.p)])
        self.assertEqual(json.loads(one(self.db,'SELECT result FROM rooms WHERE id=?',(r,))['result']),[self.p])
    def test_cannot_reopen_after_break(self):
        self.complete(((51,52,53),(50,51,52)));self.act(self.org,'break',size='2',phase='final',advance='1',judge_count='2')
        with self.assertRaises(Problem): self.act(self.org,'round_state',round='1',state='open',reason='Tentativa')
    def test_equity_reason_private_and_outbox_immediate(self):
        self.act(self.eq,'conflict',judge=str(self.j1['id']),kind='speaker',target=str(self.p),reason='MOTIVO SECRETO EQUITY')
        self.assertEqual(one(self.db,'SELECT COUNT(*) AS n FROM outbox')['n'],3)
        page=self.request(f'/t/{self.c}?tab=rooms',self.org)['body'];self.assertNotIn('MOTIVO SECRETO EQUITY',page);self.assertIn('Impedimento de equidade',page)
        self.assertNotIn('MOTIVO SECRETO EQUITY',self.request(f'/t/{self.c}?tab=audit',self.org)['body'])
        self.assertIn('MOTIVO SECRETO EQUITY',self.request(f'/t/{self.c}?tab=equity',self.eq)['body'])
    def test_no_duplicate_breach_notifications(self):
        self.act(self.eq,'conflict',judge=str(self.j1['id']),kind='speaker',target=str(self.p),reason='Motivo')
        n=one(self.db,'SELECT COUNT(*) AS n FROM outbox')['n'];sync_breaches(self.db,self.c,self.org['id']);self.assertEqual(n,one(self.db,'SELECT COUNT(*) AS n FROM outbox')['n'])
    def test_cross_competition_reference_rejected(self):
        other=self.db.execute('INSERT INTO competitions(name,config,created_by) VALUES (?,?,?)',('Outro',js(DEFAULTS),self.org['id'])).lastrowid
        p=self.db.execute('INSERT INTO participants(c,name,email,society) VALUES (?,?,?,?)',(other,'Secreto','private@example.test','SDUFRJ')).lastrowid
        with self.assertRaises(Problem): self.act(self.org,'participant_status',p=str(p),status='dns',reason='Tentativa')
    def test_csrf_protected(self):
        self.assertEqual(self.request('/create',self.org,'POST',dict(name='Copa'),False)['status'],403)
    def test_duplicate_submission(self):
        data=dict(name='Orador Novo',email='novo@example.test',society='SDUFRJ',operation='one-operation')
        self.assertEqual(self.request(f'/t/{self.c}/participant',self.org,'POST',data)['status'],303)
        self.assertEqual(self.request(f'/t/{self.c}/participant',self.org,'POST',data)['status'],409)
    def test_login_works_without_chatgpt(self):
        result=self.request('/login',method='POST',data=dict(username='gustavo',password='senha-longa-teste-123'))
        self.assertEqual(result['status'],303);self.assertIn('HttpOnly',result['headers']['Set-Cookie'])
    def test_login_rate_limit_persists_failures(self):
        for i in range(10): self.assertEqual(self.request('/login',method='POST',data=dict(username='gustavo',password='wrong'))['status'],401)
        self.assertEqual(self.request('/login',method='POST',data=dict(username='gustavo',password='wrong'))['status'],429)
    def test_audit_append_only_and_hash(self):
        audit(self.db,self.c,self.org['id'],'Teste',1,after={'x':1})
        with self.assertRaises(sqlite3.IntegrityError): self.db.execute('DELETE FROM audit')
        with self.assertRaises(sqlite3.IntegrityError): self.db.execute("UPDATE audit SET reason='fraude'")
        row=one(self.db,'SELECT * FROM audit LIMIT 1');payload=[row[k] for k in ['c','actor','action','object','before_json','after_json','reason','visibility','created','previous']]
        self.assertEqual(row['digest'],digest(js(payload)))
    def test_xss_escaped(self):
        self.db.execute('UPDATE participants SET name=? WHERE id=?',('<script>alert(1)</script>',self.p))
        body=self.request(f'/t/{self.c}?tab=participants',self.org)['body'];self.assertNotIn('<script>alert(1)</script>',body);self.assertIn('&lt;script&gt;',body)
    def test_pages_render_for_organizer(self):
        for tab in ['overview','participants','team','rooms','rankings','finals','audit','emails','settings']:
            r=self.request(f'/t/{self.c}?tab={tab}',self.org);self.assertEqual(r['status'],200,tab)
        self.assertEqual(self.request('/admin',self.mod)['status'],200)
    def test_completed_pages_render(self):
        self.complete(((51,52,53),(50,51,52)))
        for user in [self.org,self.j1,self.ad]: self.assertEqual(self.request(f'/t/{self.c}?tab=rankings',user)['status'],200)
        self.assertEqual(self.request(f'/t/{self.c}?tab=scores',self.j1)['status'],200)
    def test_invite_accept_once(self):
        token=secrets.token_urlsafe(32)
        self.db.execute('INSERT INTO invites(token,email,name,society,c,roles,expires) VALUES (?,?,?,?,?,?,?)',(digest(token),'new@example.test','Novo','SDUFRJ',self.c,js(['NSM']),now()+1000))
        with transaction(self.db): uid=consume_invite(self.db,token,dict(username='novo',password='senha-nova-longa-123'))
        self.assertEqual(roles(self.db,self.c,uid),{'NSM','organizer'})
        with self.assertRaises(Problem): consume_invite(self.db,token,dict(username='novo',password='senha-nova-longa-123'))
    def test_existing_invite_requires_matching_account(self):
        token=secrets.token_urlsafe(32)
        self.db.execute('INSERT INTO invites(token,email,name,society,c,roles,expires) VALUES (?,?,?,?,?,?,?)',(digest(token),self.j1['email'],'Juiz','SDS UFBA',self.c,js(['SM']),now()+1000))
        with self.assertRaises(Problem): consume_invite(self.db,token,{},self.j2)
    def test_society_balanced_draw_and_audit(self):
        # Replace one draft round; every active speaker and exactly two judges remain assigned.
        self.act(self.org,'draw_rooms',round='1',count='1',reason='Sorteio validado')
        self.assertEqual(one(self.db,'SELECT COUNT(*) AS n FROM placements WHERE c=? AND n=1',(self.c,))['n'],2)
        r=one(self.db,'SELECT id FROM rooms WHERE c=? AND n=1',(self.c,));self.assertEqual(len(room_info(self.db,self.c,r['id'])['panel']),2)
    def test_health_works_behind_reverse_proxy(self): self.assertEqual(self.request('/health',host='127.0.0.1:8000')['status'],200)
    def test_host_validation(self): self.assertEqual(self.request('/',host='attacker.test')['status'],400)
    def test_no_mail_sent_without_smtp(self):
        enqueue(self.db,self.c,'test@example.test','Teste','Corpo');self.assertFalse(mail_worker.deliver_one(self.db));self.assertEqual(one(self.db,'SELECT status FROM outbox')['status'],'pending')

if __name__=='__main__': unittest.main()
