document.querySelectorAll('[data-filter]').forEach(input=>input.addEventListener('input',()=>{
  const query=input.value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  input.closest('.card').querySelectorAll('tbody tr').forEach(row=>{
    row.hidden=!row.textContent.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().includes(query);
  });
}));
document.querySelectorAll('form').forEach(form=>{
  const update=()=>{const output=form.querySelector('[data-total]');if(output)output.textContent=Array.from(form.querySelectorAll('[data-score]')).reduce((sum,input)=>sum+(Number(input.value)||0),0);};
  form.querySelectorAll('[data-score]').forEach(input=>input.addEventListener('input',update));
  update();
  form.addEventListener('submit',()=>{const btn=form.querySelector('button[type="submit"]');if(btn){btn.disabled=true;btn.textContent='Registrando…';}});
});
window.addEventListener('pageshow',()=>document.querySelectorAll('button[type="submit"]').forEach(btn=>{btn.disabled=false;}));
