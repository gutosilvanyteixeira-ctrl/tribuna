"""Durable SMTP outbox. Separate process, no messages emitted during builds/tests."""
import smtplib, ssl, time, os, signal
from email.message import EmailMessage
from email.utils import formatdate
from core import *

def deliver_one(db):
    if not os.environ.get('SMTP_HOST'): return False
    with transaction(db):
        # Recover a crashed worker lease. A stable Message-ID aids deduplication.
        db.execute("UPDATE outbox SET status='retry' WHERE status='sending' AND next_try<?",(now(),))
        job=one(db,"SELECT * FROM outbox WHERE status IN ('pending','retry') AND next_try<=? AND attempts<8 ORDER BY id LIMIT 1",(now(),))
        if not job: return False
        db.execute("UPDATE outbox SET status='sending',attempts=attempts+1,next_try=? WHERE id=?",(now()+300,job['id']))
    try:
        sender=email(os.environ['SMTP_FROM']);message=EmailMessage();message['From']=sender;message['To']=job['recipient'];message['Subject']=job['subject'];message['Date']=formatdate(localtime=False)
        message['Message-ID']='<'+job['message_key']+'@'+sender.split('@')[1]+'>'
        if job['reply_to']: message['Reply-To']=job['reply_to']
        message.set_content(job['body'])
        host=os.environ['SMTP_HOST'];port=int(os.environ.get('SMTP_PORT','587'));mode=os.environ.get('SMTP_TLS','starttls')
        if mode not in ('ssl','starttls'): raise ValueError('SMTP_TLS must be ssl or starttls')
        context=ssl.create_default_context()
        client=smtplib.SMTP_SSL(host,port,timeout=25,context=context) if mode=='ssl' else smtplib.SMTP(host,port,timeout=25)
        with client:
            if mode=='starttls': client.starttls(context=context)
            if os.environ.get('SMTP_USER'): client.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD'])
            client.send_message(message)
        with transaction(db):
            db.execute("UPDATE outbox SET status='sent',error='' WHERE id=?",(job['id'],));audit(db,job['c'],None,'E-mail entregue ao servidor SMTP',job['id'],after=dict(recipient=job['recipient']))
    except Exception as exc:
        # Do not persist server messages or secrets returned by SMTP.
        code=type(exc).__name__;attempt=job['attempts']+1
        with transaction(db): db.execute('UPDATE outbox SET status=?,error=?,next_try=? WHERE id=?',('failed' if attempt>=8 else 'retry',code,now()+min(3600,30*2**attempt),job['id']))
    return True

if __name__=='__main__':
    init();db=connect()
    print('Fila de e-mail iniciada. SMTP '+('configurado' if os.environ.get('SMTP_HOST') else 'não configurado; mensagens permanecerão pendentes')+'.')
    while True:
        processed=deliver_one(db)
        time.sleep(1 if processed else 3)
