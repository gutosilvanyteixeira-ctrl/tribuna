"""Competition rules. All mutations execute in the caller's SQLite transaction."""
import json, secrets, itertools
from decimal import Decimal, InvalidOperation
from fractions import Fraction
from urllib.parse import urlsplit
from core import *

def member_list(db,c):
    result=rows(db,'SELECT u.id,u.name,u.email,u.society,u.active,m.roles FROM memberships m JOIN users u ON u.id=m.u WHERE m.c=? ORDER BY u.name',(c,))
    for r in result: r['roles']=sorted(effective_roles(json.loads(r['roles'])))
    return result
def judges(db,c): return [u for u in member_list(db,c) if u['active'] and set(u['roles'])&{'SM','NSM'}]
def organizers(db,c): return [u['id'] for u in member_list(db,c) if 'organizer' in u['roles']]
def room_info(db,c,room):
    r=one(db,'SELECT * FROM rooms WHERE id=? AND c=?',(room,c))
    if not r: raise Problem('Sala inválida.')
    r['panel']=[x['u'] for x in rows(db,'SELECT u FROM panels WHERE room=?',(room,))]
    r['people']=rows(db,'SELECT p.*,l.position FROM placements l JOIN participants p ON p.id=l.p WHERE l.room=? ORDER BY l.position,p.name',(room,))
    return r
def state(db,c,n):
    x=one(db,'SELECT state FROM rounds WHERE c=? AND n=?',(c,n))
    if not x: raise Problem('Rodada inexistente.')
    return x['state']
def closed(db,c): return all(state(db,c,n)=='closed' for n in (1,2,3))
def reason(data): return required(data,'reason',2000)
def participant(db,c,p):
    r=one(db,'SELECT * FROM participants WHERE id=? AND c=?',(p,c))
    if not r: raise Problem('Orador inválido.')
    return r
def all_scores(db,c,p,n):
    r=rows(db,'SELECT * FROM scores WHERE c=? AND p=? AND n=? ORDER BY j',(c,p,n))
    for x in r: x['values']=json.loads(x['values_json']); x['total']=sum(x['values'])
    return r
def score_signature(scores): return digest(js([(r['j'],r['version'],r['values']) for r in scores]))
def speech(db,c,p,n): return one(db,'SELECT * FROM speeches WHERE c=? AND p=? AND n=?',(c,p,n)) or dict(url='',absent=0,penalty=0,seconds=None,reason='')
def result_of(db,c,p,n):
    sc=all_scores(db,c,p,n); sp=speech(db,c,p,n)
    if len(sc)!=2 or sp['absent']: return None
    return Fraction(sum(x['total'] for x in sc),2)-Fraction(sp['penalty'],100)
def ranking(db,c):
    ranked=[]; excluded=[]
    for p in rows(db,'SELECT * FROM participants WHERE c=? ORDER BY name',(c,)):
        values=[result_of(db,c,p['id'],n) for n in (1,2,3)]
        if p['status']!='active' or None in values:
            excluded.append(p); continue
        p['rounds']=values;p['mean']=sum(values)/3;p['best']=sorted(values,reverse=True)
        p['key']=(p['mean'],*p['best']);ranked.append(p)
    ranked.sort(key=lambda p:p['key'],reverse=True)
    pending=[]; final=[]
    for key,g in itertools.groupby(ranked,key=lambda p:p['key']):
        group=list(g)
        if len(group)>1:
            signature=digest(js([sorted(p['id'] for p in group),[str(x) for x in key]]))
            draw=one(db,'SELECT ordering FROM draws WHERE c=? AND signature=?',(c,signature))
            if draw:
                order=json.loads(draw['ordering']); group.sort(key=lambda p:order.index(p['id']))
            else: pending.append(dict(signature=signature,ids=[p['id'] for p in group],names=[p['name'] for p in group]))
        final+=group
    return final,excluded,pending
def conflict_warnings(db,c,room):
    r=room_info(db,c,room); warnings=[];ids={p['id'] for p in r['people']}
    for cf in rows(db,'SELECT * FROM conflicts WHERE c=? AND active=1',(c,)):
        if cf['judge'] in r['panel'] and ((cf['kind']=='speaker' and cf['target'] in ids) or (cf['kind']=='judge' and cf['target'] in r['panel'])):
            warnings.append(dict(kind='impediment',id=cf['id'],message='Impedimento de equidade nesta sala.'))
    users={u['id']:u for u in member_list(db,c)}
    for j in r['panel']:
        for p in r['people']:
            if users[j]['society']==p['society']: warnings.append(dict(kind='society',message=f"{users[j]['name']} e {p['name']}: mesma sociedade."))
    for a,b in itertools.combinations(r['panel'],2):
        if users[a]['society']==users[b]['society']: warnings.append(dict(kind='society',message='Juízes da mesma sociedade nesta mesa.'))
    return warnings
def sync_breaches(db,c,actor):
    active=set()
    for room in rows(db,'SELECT id FROM rooms WHERE c=?',(c,)):
        for warn in conflict_warnings(db,c,room['id']):
            if warn['kind']!='impediment': continue
            pair=(warn['id'],room['id']);active.add(pair)
            previous=one(db,'SELECT active FROM breaches WHERE conflict=? AND room=?',pair)
            if previous and previous['active']: continue
            db.execute('INSERT INTO breaches VALUES (?,?,1) ON CONFLICT(conflict,room) DO UPDATE SET active=1',pair)
            rr=room_info(db,c,room['id'])
            notify(db,c,[u['id'] for u in member_list(db,c) if 'equity' in u['roles']],f"Impedimento #{warn['id']} desrespeitado em {rr['name']}, rodada {rr['n']}. Consulte a área de equidade.",True)
            audit(db,c,actor,'Quebra de impedimento',room['id'],after=dict(conflict=warn['id']),visibility='equity')
    for b in rows(db,'SELECT b.* FROM breaches b JOIN conflicts f ON f.id=b.conflict WHERE f.c=? AND b.active=1',(c,)):
        if (b['conflict'],b['room']) not in active: db.execute('UPDATE breaches SET active=0 WHERE conflict=? AND room=?',(b['conflict'],b['room']))
def changed_room(db,c,n,actor,message,old_judges=()):
    if state(db,c,n)!='draft':
        users=old_judges+tuple(x['u'] for x in rows(db,'SELECT DISTINCT p.u FROM panels p JOIN rooms r ON r.id=p.room WHERE r.c=? AND r.n=?',(c,n)))+tuple(organizers(db,c))
        notify(db,c,users,message,True)
    sync_breaches(db,c,actor)
def unlocked(db,c,n):
    if state(db,c,n)=='closed': raise Problem('Reabra a rodada com justificativa antes de alterar seus resultados.')

def draw_round(db,c,n,count,actor,data):
    if state(db,c,n)!='draft': raise Problem('Sorteio disponível somente antes de fechar as salas.')
    if one(db,'SELECT 1 FROM scores WHERE c=? AND n=?',(c,n)): raise Problem('Já existem notas nesta rodada.')
    old=rows(db,'SELECT * FROM rooms WHERE c=? AND n=?',(c,n))
    old_snapshot=[room_info(db,c,r['id']) for r in old]
    if old: why=reason(data)
    else: why='Sorteio inicial'
    ps=rows(db,"SELECT * FROM participants WHERE c=? AND status='active'",(c,));js_=judges(db,c)
    if count>len(ps): raise Problem('O número de salas não pode exceder o de participantes ativos.')
    if len(js_)<count*2: raise Problem('Cadastre pelo menos dois juízes por sala. Um juiz não pode estar em duas salas na mesma rodada.')
    # Keep the initial speaker distribution in later rounds; otherwise balance societies.
    prior=rows(db,'SELECT l.p,r.name FROM placements l JOIN rooms r ON r.id=l.room WHERE l.c=? AND l.n=1',(c,)) if n>1 else []
    prior_rooms=sorted({x['name'] for x in prior})
    groups=[[] for _ in range(count)];rng=secrets.SystemRandom()
    if len(prior_rooms)==count and {x['p'] for x in prior}=={p['id'] for p in ps}:
        mapping={x['p']:prior_rooms.index(x['name']) for x in prior}
        for p in ps: groups[mapping[p['id']]].append(p)
    else:
        rng.shuffle(ps);ps.sort(key=lambda p:sum(q['society']==p['society'] for q in ps),reverse=True)
        for p in ps:
            choices=list(range(count));rng.shuffle(choices)
            idx=min(choices,key=lambda i:(len(groups[i]),sum(q['society']==p['society'] for q in groups[i])))
            groups[idx].append(p)
    conflicts=rows(db,'SELECT * FROM conflicts WHERE c=? AND active=1',(c,))
    def cost(permutation):
        total=0
        for i,group in enumerate(groups):
            panel=permutation[2*i:2*i+2];pids={p['id'] for p in group};jids={j['id'] for j in panel}
            total+=sum(10000 for f in conflicts if f['judge'] in jids and ((f['kind']=='speaker' and f['target'] in pids) or (f['kind']=='judge' and f['target'] in jids)))
            total+=sum(20 for j in panel for p in group if j['society']==p['society'])
            total+=20*(panel[0]['society']==panel[1]['society'])
            total+=3*(not any('SM' in j['roles'] for j in panel))
        return total
    best=None;best_cost=None
    for _ in range(1000):
        rng.shuffle(js_);value=cost(js_)
        if best_cost is None or value<best_cost: best=list(js_);best_cost=value
        if value==0: break
    db.execute('DELETE FROM placements WHERE c=? AND n=?',(c,n))
    for r in old:
        db.execute('DELETE FROM breaches WHERE room=?',(r['id'],));db.execute('DELETE FROM panels WHERE room=?',(r['id'],))
    db.execute('DELETE FROM rooms WHERE c=? AND n=?',(c,n))
    after=[]
    for i,group in enumerate(groups):
        panel=best[2*i:2*i+2]; chair=next((j['id'] for j in panel if 'SM' in j['roles']),panel[0]['id'])
        rid=db.execute('INSERT INTO rooms(c,n,name,chair) VALUES (?,?,?,?)',(c,n,f'Sala {i+1}',chair)).lastrowid
        db.executemany('INSERT INTO panels VALUES (?,?)',[(rid,j['id']) for j in panel])
        rng.shuffle(group)
        db.executemany('INSERT INTO placements VALUES (?,?,?,?,?)',[(c,n,p['id'],rid,k+1) for k,p in enumerate(group)])
        after.append(dict(room=rid,panel=[j['id'] for j in panel],people=[p['id'] for p in group],chair=chair))
    audit(db,c,actor,'Sorteio de salas',n,before=old_snapshot,after=after,reason=why)
    sync_breaches(db,c,actor)

def validate_close(db,c,n):
    rms=rows(db,'SELECT * FROM rooms WHERE c=? AND n=?',(c,n))
    if not rms: raise Problem('Gere as salas primeiro.')
    if n<=3:
        active=rows(db,"SELECT id FROM participants WHERE c=? AND status='active'",(c,))
        for p in active:
            if not one(db,'SELECT 1 FROM placements WHERE c=? AND n=? AND p=?',(c,n,p['id'])): raise Problem('Há oradores ativos sem sala.')
        for r in rms:
            panel=[x['u'] for x in rows(db,'SELECT u FROM panels WHERE room=?',(r['id'],))]
            if len(panel)!=2 or r['chair'] not in panel: raise Problem('Cada sala precisa de dois juízes e um presidente.')
            for p in rows(db,"SELECT p.id FROM placements l JOIN participants p ON p.id=l.p WHERE l.room=? AND p.status='active'",(r['id'],)):
                if speech(db,c,p['id'],n)['absent']: continue
                scores=all_scores(db,c,p['id'],n)
                if {s['j'] for s in scores}!=set(panel): raise Problem('Existem avaliações pendentes ou de juízes não alocados.')
                if abs(scores[0]['total']-scores[1]['total'])>=4:
                    waiver=one(db,'SELECT signature FROM waivers WHERE c=? AND p=? AND n=?',(c,p['id'],n))
                    if not waiver or waiver['signature']!=score_signature(scores): raise Problem('Justifique as divergências de quatro ou mais pontos antes de encerrar.')
    elif any(not r['result'] for r in rms): raise Problem('Aguarde os presidentes registrarem os resultados.')

def handle(db,user,c,action,data):
    uid=user['id'];rr=allow(db,c,uid);comp=competition(db,c)
    org='organizer' in rr; judge=bool(rr&{'SM','NSM'})
    def admin():
        if not org: raise Problem('Esta ação é da organização.',403)
    if action=='judge_add':
        admin();add_judge_with_link(db,user,c,data);return
    if action=='judge_link':
        admin();create_judge_link(db,user,c,integer(data,'user',1),integer(data,'days',1,365),reason(data));return
    if action=='judge_revoke':
        admin();target=integer(data,'user',1);why=reason(data)
        previous=rows(db,'SELECT id FROM judge_links WHERE c=? AND u=? AND revoked=0',(c,target))
        if not previous: raise Problem('Não há link ativo para revogar.')
        db.execute('UPDATE judge_links SET revoked=1 WHERE c=? AND u=?',(c,target));audit(db,c,uid,'Link de juiz revogado',target,before=previous,after=[],reason=why);return
    if action=='publish':
        admin();cfg=dict(comp['config']);old=public_config(comp)
        pub=dict(PUBLIC_DEFAULTS)
        for key in ('enabled','roster','team','rankings','break','champion'): pub[key]=data.get(key)=='yes'
        pub['intro']=str(data.get('intro','')).strip()[:5000]
        pub['rounds']=sorted({int(x) for x in data.get('public_rounds',[]) if str(x).isdigit() and 1<=int(x)<=5})
        if pub['rankings'] and not closed(db,c): raise Problem('Encerre as três classificatórias antes de publicar rankings.')
        if pub['break'] and not comp['break_spec']: raise Problem('Gere o break antes de publicá-lo.')
        if pub['champion'] and not one(db,'SELECT 1 FROM rooms WHERE c=? AND n=5 AND result IS NOT NULL',(c,)): raise Problem('A final ainda não tem campeão registrado.')
        for n in pub['rounds']:
            if state(db,c,n)=='draft': raise Problem('Feche as salas da rodada antes de publicá-las.')
        cfg['public']=pub;db.execute('UPDATE competitions SET config=? WHERE id=?',(js(cfg),c));audit(db,c,uid,'Publicação alterada',c,old,pub,reason(data));return
    if action=='invite': issue_invite(db,user,data,c); return
    if action=='society':
        admin();name=required(data,'name',100);db.execute('INSERT OR IGNORE INTO societies VALUES (?)',(name,));audit(db,c,uid,'Sociedade cadastrada',name);return
    if action=='member_remove':
        admin();target=integer(data,'user',1);why=reason(data)
        old=roles(db,c,target)
        if not old: raise Problem('Membro inexistente.')
        if 'organizer' in old and len(organizers(db,c))==1: raise Problem('Mantenha ao menos um organizador.')
        if one(db,'SELECT 1 FROM panels p JOIN rooms r ON r.id=p.room WHERE r.c=? AND p.u=?',(c,target)): raise Problem('Substitua o membro nas mesas antes de removê-lo.')
        db.execute('DELETE FROM memberships WHERE c=? AND u=?',(c,target));audit(db,c,uid,'Membro removido',target,before=sorted(old),reason=why);return
    if action=='settings':
        admin()
        if one(db,'SELECT 1 FROM scores WHERE c=?',(c,)): raise Problem('Regras de pontuação ficam bloqueadas após a primeira avaliação. Edite mensagens na aba E-mails.')
        cfg=dict(comp['config']);before=dict(cfg)
        for field,allowed in [('penalty_mode',('manual','automatic')),('speech_tie',('golden','individual'))]:
            v=required(data,field)
            if v not in allowed: raise Problem('Regra inválida.')
            cfg[field]=v
        for field,lo,hi in [('limit_seconds',1,3600),('tolerance_seconds',0,600),('rate_cents',0,1500),('top_size',1,1000)]: cfg[field]=integer(data,field,lo,hi)
        db.execute('UPDATE competitions SET config=? WHERE id=?',(js(cfg),c));audit(db,c,uid,'Regras configuradas',c,before, cfg);return
    if action=='participant':
        admin();name=required(data,'name');address=email(required(data,'email'));soc=required(data,'society')
        if not one(db,'SELECT 1 FROM societies WHERE name=?',(soc,)): raise Problem('Sociedade inválida.')
        if one(db,"SELECT 1 FROM rounds WHERE c=? AND state!='draft'",(c,)): raise Problem('Cadastre participantes antes de fechar as salas.')
        pid=db.execute('INSERT INTO participants(c,name,email,society) VALUES (?,?,?,?)',(c,name,address,soc)).lastrowid
        audit(db,c,uid,'Orador cadastrado',pid,after=dict(name=name,email=address,society=soc));return
    if action=='participant_status':
        admin();p=integer(data,'p',1);old=participant(db,c,p);why=reason(data)
        if closed(db,c) or comp['break_spec']: raise Problem('Reabra uma classificatória antes de alterar a participação.')
        status=required(data,'status')
        if status not in ('active','dns'): raise Problem('Situação inválida.')
        db.execute('UPDATE participants SET status=? WHERE id=?',(status,p));audit(db,c,uid,'Participação alterada',p,old,dict(status=status),why);return
    if action=='draw_rooms':
        admin();n=integer(data,'round',1,3);draw_round(db,c,n,integer(data,'count',1,100),uid,data);return
    if action=='move':
        admin();p=integer(data,'p',1);participant(db,c,p);rid=integer(data,'room',1);r=room_info(db,c,rid);n=r['n'];unlocked(db,c,n)
        why=reason(data);old=one(db,'SELECT * FROM placements WHERE c=? AND n=? AND p=?',(c,n,p))
        if not old: raise Problem('Orador não pertence a esta rodada.')
        if one(db,'SELECT 1 FROM scores WHERE c=? AND p=? AND n=?',(c,p,n)) or (n>3 and any(x['result'] for x in rows(db,'SELECT result FROM rooms WHERE c=? AND n=?',(c,n)))): raise Problem('Não é possível mover após o registro de avaliações ou resultados.')
        pos=integer(data,'position',1,10000)
        db.execute('UPDATE placements SET room=?,position=? WHERE c=? AND n=? AND p=?',(rid,pos,c,n,p))
        audit(db,c,uid,'Orador realocado',p,old,dict(room=rid,position=pos),why);changed_room(db,c,n,uid,'Alocação de orador alterada na rodada '+str(n));return
    if action=='panel':
        admin();rid=integer(data,'room',1);r=room_info(db,c,rid);n=r['n'];unlocked(db,c,n);why=reason(data)
        selected=list(dict.fromkeys(int(x) for x in data.get('judges',[]) if str(x).isdigit()));valid={j['id'] for j in judges(db,c)}
        needed=2 if n<=3 else integer(data,'judge_count',1,15)
        if len(selected)!=needed or not set(selected)<=valid: raise Problem('Selecione a quantidade indicada de juízes cadastrados.')
        chair=integer(data,'chair',1)
        if chair not in selected: raise Problem('O presidente deve integrar a mesa.')
        for j in selected:
            if one(db,'SELECT 1 FROM panels p JOIN rooms r ON r.id=p.room WHERE r.c=? AND r.n=? AND r.id!=? AND p.u=?',(c,n,rid,j)): raise Problem('Um dos juízes já está em outra sala desta rodada.')
        removed=set(r['panel'])-set(selected)
        for j in removed:
            if one(db,'SELECT 1 FROM scores s JOIN placements l ON s.c=l.c AND s.p=l.p AND s.n=l.n WHERE l.room=? AND s.j=?',(rid,j)): raise Problem('O juiz já tem notas registradas. Use o lançamento substituto para avaliações pendentes.')
        if r['result']: raise Problem('A sala já tem resultado.')
        db.execute('DELETE FROM panels WHERE room=?',(rid,));db.executemany('INSERT INTO panels VALUES (?,?)',[(rid,j) for j in selected]);db.execute('UPDATE rooms SET chair=? WHERE id=?',(chair,rid))
        audit(db,c,uid,'Mesa alterada',rid,dict(panel=r['panel'],chair=r['chair']),dict(panel=selected,chair=chair),why);changed_room(db,c,n,uid,'Mesa de julgamento alterada na rodada '+str(n),tuple(r['panel']));return
    if action=='round_state':
        admin();n=integer(data,'round',1,5);old=state(db,c,n);target=required(data,'state');why=reason(data)
        if (old,target) not in [('draft','open'),('open','closed'),('closed','open')]: raise Problem('Transição inválida.')
        if target=='open' and old=='draft':
            rms=rows(db,'SELECT id FROM rooms WHERE c=? AND n=?',(c,n))
            if not rms: raise Problem('Gere as salas primeiro.')
            for r_ in rms:
                r=room_info(db,c,r_['id'])
                if not r['panel'] or r['chair'] not in r['panel'] or (n<=3 and len(r['panel'])!=2): raise Problem('Complete as mesas antes de fechar as salas.')
        if target=='closed': validate_close(db,c,n)
        if old=='closed' and (comp['break_spec'] if n<=3 else one(db,'SELECT 1 FROM rooms WHERE c=? AND n=5',(c,))): raise Problem('Já há uma fase dependente. Não é permitido invalidar o break ou a final.')
        db.execute('UPDATE rounds SET state=? WHERE c=? AND n=?',(target,c,n));audit(db,c,uid,'Estado da rodada',n,old,target,why)
        notify(db,c,organizers(db,c)+[j['id'] for j in judges(db,c)],f'Rodada {n}: '+{'open':'salas fechadas, avaliação aberta','closed':'encerrada'}[target]);return
    if action=='speech':
        admin();p=integer(data,'p',1);participant(db,c,p);n=integer(data,'round',1,3);unlocked(db,c,n);old=speech(db,c,p,n);why=reason(data)
        url=str(data.get('url','')).strip()
        if url and (urlsplit(url).scheme not in ('http','https') or not urlsplit(url).netloc or len(url)>2000): raise Problem('Use um link HTTP ou HTTPS válido.')
        seconds=integer(data,'seconds',0,86400) if data.get('seconds','').strip() else None
        cfg=comp['config']
        if cfg['penalty_mode']=='automatic':
            if seconds is None: raise Problem('Informe a duração para calcular a penalidade.')
            penalty=max(0,seconds-cfg['limit_seconds']-cfg['tolerance_seconds'])*cfg['rate_cents']
        else:
            try:
                value=Decimal(str(data.get('penalty','0')).replace(',','.'))
                if not value.is_finite() or value<0 or value>10000 or value*100!=(value*100).to_integral(): raise ValueError()
                penalty=int(value*100)
            except (InvalidOperation,ValueError): raise Problem('Desconto inválido. Use até duas casas decimais.')
        absent=int(data.get('absent')=='yes')
        db.execute('INSERT INTO speeches VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(c,p,n) DO UPDATE SET url=excluded.url,absent=excluded.absent,seconds=excluded.seconds,penalty=excluded.penalty,reason=excluded.reason',(c,p,n,url,absent,seconds,penalty,why))
        audit(db,c,uid,'Dados do discurso',f'{p}/{n}',old,dict(url=url,absent=absent,seconds=seconds,penalty=penalty),why);return
    if action=='score':
        if not judge: raise Problem('Somente SM e NSM podem lançar notas.',403)
        p=integer(data,'p',1);person=participant(db,c,p);n=integer(data,'round',1,3);j=integer(data,'judge',1)
        if state(db,c,n)!='open': raise Problem('A rodada não está aberta para avaliação.')
        if person['status']!='active' or speech(db,c,p,n)['absent']: raise Problem('Orador marcado como ausente.')
        allocation=one(db,'SELECT room FROM placements WHERE c=? AND n=? AND p=?',(c,n,p))
        if not allocation: raise Problem('Orador sem sala.')
        panel=room_info(db,c,allocation['room'])['panel']
        if j not in panel: raise Problem('Juiz não alocado para este discurso.')
        old=one(db,'SELECT * FROM scores WHERE c=? AND p=? AND n=? AND j=?',(c,p,n,j));substitute=j!=uid
        if substitute and old: raise Problem('Você não pode visualizar ou sobrescrever a avaliação de outro juiz.',403)
        if not substitute and uid not in panel: raise Problem('Você não está nesta mesa.',403)
        values=[integer(data,'criterion'+str(i),0,15) for i in range(5)]
        why=reason(data) if old or substitute else ''
        version=integer(data,'version',0,100000)
        if version!=(old['version'] if old else 0): raise Problem('A avaliação mudou. Atualize a página antes de continuar.',409)
        db.execute('INSERT INTO scores VALUES (?,?,?,?,?,?,1) ON CONFLICT(c,p,n,j) DO UPDATE SET values_json=excluded.values_json,submitted_by=excluded.submitted_by,version=scores.version+1',(c,p,n,j,js(values),uid))
        audit(db,c,uid,'Nota substituta' if substitute else ('Nota corrigida' if old else 'Nota enviada'),f'{p}/{n}/{j}',dict(values=json.loads(old['values_json'])) if old else None,dict(values=values,judge=j),why,visibility='scores')
        if substitute: notify(db,c,[j]+organizers(db,c),'Uma avaliação foi registrada em nome de outro juiz, com justificativa. Consulte o histórico após a liberação das notas.')
        return
    if action=='waiver':
        p=integer(data,'p',1);participant(db,c,p);n=integer(data,'round',1,3);unlocked(db,c,n);why=reason(data)
        allocation=one(db,'SELECT room FROM placements WHERE c=? AND n=? AND p=?',(c,n,p))
        if not org and (not judge or not allocation or uid not in room_info(db,c,allocation['room'])['panel']): raise Problem('Somente a mesa ou a organização pode justificar.',403)
        scores=all_scores(db,c,p,n)
        if len(scores)!=2 or abs(scores[0]['total']-scores[1]['total'])<4: raise Problem('Não há divergência pendente.')
        db.execute('INSERT INTO waivers VALUES (?,?,?,?,?) ON CONFLICT(c,p,n) DO UPDATE SET signature=excluded.signature,reason=excluded.reason',(c,p,n,score_signature(scores),why));audit(db,c,uid,'Divergência mantida',f'{p}/{n}',after='Justificada',reason=why);return
    if action=='conflict':
        if rr!={'equity'}: raise Problem('Somente a equidade registra impedimentos.',403)
        j=integer(data,'judge',1);kind=required(data,'kind');target=integer(data,'target',1);valid={j['id'] for j in judges(db,c)}
        if j not in valid or kind not in ('speaker','judge'): raise Problem('Impedimento inválido.')
        if kind=='speaker': participant(db,c,target)
        elif target not in valid or target==j: raise Problem('Selecione outro juiz do campeonato.')
        why=reason(data);fid=db.execute('INSERT INTO conflicts(c,judge,kind,target,reason) VALUES (?,?,?,?,?)',(c,j,kind,target,why)).lastrowid
        audit(db,c,uid,'Impedimento registrado',fid,after=dict(judge=j,kind=kind,target=target,reason=why),visibility='equity');sync_breaches(db,c,uid);return
    if action=='conflict_remove':
        if rr!={'equity'}: raise Problem('Somente a equidade.',403)
        fid=integer(data,'id',1);old=one(db,'SELECT * FROM conflicts WHERE id=? AND c=?',(fid,c))
        if not old: raise Problem('Impedimento inválido.')
        why=reason(data);db.execute('UPDATE conflicts SET active=0 WHERE id=?',(fid,));audit(db,c,uid,'Impedimento retirado',fid,old,None,why,visibility='equity');sync_breaches(db,c,uid);return
    if action=='lottery':
        admin()
        if not closed(db,c): raise Problem('Encerre as três classificatórias.')
        ranked,excluded,pending=ranking(db,c)
        for tie in pending:
            order=list(tie['ids']);secrets.SystemRandom().shuffle(order)
            db.execute('INSERT INTO draws VALUES (?,?,?)',(c,tie['signature'],js(order)))
            audit(db,c,uid,'Sorteio de desempate',tie['signature'],tie['ids'],order,'Golden, Silver e Bronze idênticos; ordem sorteada e persistida.')
        if not pending: raise Problem('Não há empate pendente de sorteio.')
        return
    if action=='top_options':
        admin()
        if not closed(db,c): raise Problem('Encerre as classificatórias antes de montar o top.')
        cfg=dict(comp['config']);old=dict(cfg);cfg['repeat_speakers']=data.get('repeat')=='yes';cfg['top_size']=integer(data,'top_size',1,1000)
        db.execute('UPDATE competitions SET config=? WHERE id=?',(js(cfg),c));audit(db,c,uid,'Top de discursos configurado',c,old,cfg);return
    if action=='break':
        admin()
        if not closed(db,c): raise Problem('Encerre as três classificatórias.')
        if comp['break_spec']: raise Problem('O break já foi gerado.')
        ranked,excluded,pending=ranking(db,c)
        if pending: raise Problem('Resolva o sorteio de desempate primeiro.')
        size=integer(data,'size',1,len(ranked));phase=required(data,'phase');judges_count=integer(data,'judge_count',1,15)
        if phase not in ('semi','final'): raise Problem('Fase inválida.')
        selected=ranked[:size];reserve=ranked[size:];n=4 if phase=='semi' else 5
        if phase=='semi':
            if size%2: raise Problem('Semifinais precisam de número par de oradores.')
            advance=integer(data,'advance',1,size//2)
            groups=[[],[]]
            for i,p in enumerate(selected): groups[0 if i%4 in (0,3) else 1].append(p)
        else: advance=1;groups=[selected]
        db.execute("INSERT INTO rounds VALUES (?,?,'draft')",(c,n))
        for i,group in enumerate(groups):
            rid=db.execute('INSERT INTO rooms(c,n,name,advance) VALUES (?,?,?,?)',(c,n,'Semifinal '+str(i+1) if phase=='semi' else 'Final de PS',advance)).lastrowid
            db.executemany('INSERT INTO placements VALUES (?,?,?,?,?)',[(c,n,p['id'],rid,k+1) for k,p in enumerate(group)])
        spec=dict(phase=phase,size=size,advance=advance,judge_count=judges_count,reserves=[p['id'] for p in reserve])
        db.execute('UPDATE competitions SET break_spec=? WHERE id=?',(js(spec),c));audit(db,c,uid,'Break gerado',c,after=spec);return
    if action=='reserve':
        admin();rid=integer(data,'room',1);r=room_info(db,c,rid);unlocked(db,c,r['n'])
        if r['n'] not in (4,5) or r['result']: raise Problem('Sala indisponível para substituição.')
        p=integer(data,'p',1);new=integer(data,'replacement',1);why=reason(data)
        placement=one(db,'SELECT * FROM placements WHERE room=? AND p=?',(rid,p))
        spec=json.loads(comp['break_spec'] or '{}')
        if not placement or new not in spec.get('reserves',[]): raise Problem('Selecione um orador da sala e um reserva do break.')
        if one(db,'SELECT 1 FROM placements WHERE c=? AND n=? AND p=?',(c,r['n'],new)): raise Problem('O reserva já está alocado.')
        db.execute('DELETE FROM placements WHERE c=? AND n=? AND p=?',(c,r['n'],p));db.execute('INSERT INTO placements VALUES (?,?,?,?,?)',(c,r['n'],new,rid,placement['position']))
        spec['reserves'].remove(new);db.execute('UPDATE competitions SET break_spec=? WHERE id=?',(js(spec),c));audit(db,c,uid,'Reserva convocado',rid,dict(speaker=p),dict(speaker=new),why);changed_room(db,c,r['n'],uid,'Convocação de reserva em '+r['name']);return
    if action=='decision':
        rid=integer(data,'room',1);r=room_info(db,c,rid)
        if r['n'] not in (4,5) or state(db,c,r['n'])!='open': raise Problem('Eliminatória não está aberta.')
        if uid!=r['chair'] or not judge: raise Problem('Somente o presidente desta mesa registra o resultado.',403)
        if r['n']==4 and one(db,'SELECT 1 FROM rooms WHERE c=? AND n=5',(c,)): raise Problem('A final já foi gerada.')
        winners=list(dict.fromkeys(int(x) for x in data.get('winners',[]) if str(x).isdigit()))
        expected=r['advance'] if r['n']==4 else 1
        if len(winners)!=expected or not set(winners)<={p['id'] for p in r['people']}: raise Problem(f'Selecione exatamente {expected} orador(es) desta sala.')
        old=json.loads(r['result']) if r['result'] else None;why=reason(data) if old else ''
        db.execute('UPDATE rooms SET result=? WHERE id=?',(js(winners),rid));audit(db,c,uid,'Resultado da mesa',rid,old,winners,why)
        if r['n']==4:
            semis=rows(db,'SELECT result FROM rooms WHERE c=? AND n=4 ORDER BY id',(c,))
            if all(s['result'] for s in semis):
                finalists=[p for s in semis for p in json.loads(s['result'])]
                db.execute("INSERT INTO rounds VALUES (?,5,'draft')",(c,));final=db.execute("INSERT INTO rooms(c,n,name,advance) VALUES (?,5,'Final de PS',1)",(c,)).lastrowid
                db.executemany('INSERT INTO placements VALUES (?,5,?,?,?)',[(c,p,final,i+1) for i,p in enumerate(finalists)])
                audit(db,c,uid,'Final de PS gerada',final,after=finalists);notify(db,c,organizers(db,c),'Final de PS gerada. Defina a mesa e feche a sala.')
        return
    if action in ('mail_save','mail_send'):
        admin();cfg=dict(comp['config']);before=dict(cfg)
        for field,limit in [('mail_subject',200),('mail_body',20000)]: cfg[field]=required(data,field,limit)
        cfg['links']=str(data.get('links',''))[:10000];cfg['reply_to']=email(data['reply_to']) if data.get('reply_to','').strip() else ''
        db.execute('UPDATE competitions SET config=? WHERE id=?',(js(cfg),c))
        if action=='mail_send':
            if data.get('confirm')!='yes': raise Problem('Confirme o envio para os inscritos.')
            for p in rows(db,'SELECT * FROM participants WHERE c=?',(c,)):
                body=cfg['mail_body'];subject=cfg['mail_subject']
                for key,val in {'nome':p['name'],'campeonato':comp['name'],'links':cfg['links']}.items(): body=body.replace('{'+key+'}',val);subject=subject.replace('{'+key+'}',val)
                enqueue(db,c,p['email'],subject,body,cfg['reply_to'])
        audit(db,c,uid,'E-mails enfileirados' if action=='mail_send' else 'Mensagem configurada',c,before,cfg);return
    raise Problem('Ação desconhecida.',404)
