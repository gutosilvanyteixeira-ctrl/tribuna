import argparse,getpass,sys,json,os
from core import *

def main():
    parser=argparse.ArgumentParser(description='Administração do Tribuna')
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('init');bootstrap=sub.add_parser('bootstrap');bootstrap.add_argument('--email',required=True);bootstrap.add_argument('--username',default='gustavo.silvany');bootstrap.add_argument('--name',default='Gustavo Silvany');bootstrap.add_argument('--society',default='SDS UFBA')
    sub.add_parser('verify-audit')
    backup=sub.add_parser('backup');backup.add_argument('destination')
    sub.add_parser('retry-emails')
    args=parser.parse_args();init();db=connect()
    if args.command=='bootstrap':
        if one(db,'SELECT 1 FROM users'): raise SystemExit('Bootstrap permitido somente em uma instalação vazia.')
        pw=getpass.getpass('Senha inicial (mínimo 12 caracteres): ')
        if pw!=getpass.getpass('Repita a senha: '): raise SystemExit('Senhas diferentes.')
        hashed=password_hash(pw)
        with transaction(db):
            db.execute('INSERT OR IGNORE INTO societies VALUES (?)',(args.society,))
            uid=db.execute('INSERT INTO users(username,email,name,society,password,moderator,organizer) VALUES (?,?,?,?,?,1,1)',(args.username,email(args.email),args.name,args.society,hashed)).lastrowid
            audit(db,None,uid,'Moderação inicial criada',uid,after=dict(name=args.name,society=args.society))
        print('Conta inicial criada. Nenhuma senha foi gravada em texto simples.')
    elif args.command=='verify-audit':
        previous='0'*64;count=0
        for r in rows(db,'SELECT * FROM audit ORDER BY id'):
            payload=[r[k] for k in ['c','actor','action','object','before_json','after_json','reason','visibility','created','previous']]
            if r['previous']!=previous or r['digest']!=digest(js(payload)): raise SystemExit('Falha de integridade no registro '+str(r['id']))
            previous=r['digest'];count+=1
        print(f'{count} registros verificados. Último hash: {previous}')
    elif args.command=='backup':
        dest=Path(args.destination)
        if dest.exists(): raise SystemExit('Destino já existe; escolha um novo caminho.')
        dest.parent.mkdir(parents=True,exist_ok=True)
        out=sqlite3.connect(str(dest));db.backup(out);out.close();os.chmod(dest,0o600);print('Backup criado.')
    elif args.command=='retry-emails':
        db.execute("UPDATE outbox SET status='retry',next_try=0,attempts=0 WHERE status='failed'");print('Mensagens com falha recolocadas na fila. Verifique antes se o provedor já as entregou.')
    else: print('Banco inicializado.')
    db.close()

if __name__=='__main__': main()
