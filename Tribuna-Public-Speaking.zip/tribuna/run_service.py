"""Run HTTP and mail processes together when the host provides one persistent disk."""
import os,signal,subprocess,sys,time
from core import init

def main():
    init();children=[];stopping=False
    def stop(signum=None,frame=None):
        nonlocal stopping
        stopping=True
        for p in children:
            if p.poll() is None: p.terminate()
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    port=int(os.environ.get('PORT','8000'))
    if not 1<=port<=65535: raise SystemExit('Invalid PORT')
    commands=[['gunicorn','--bind',f'0.0.0.0:{port}','--workers','2','--threads','4','--timeout','60','app:application'],[sys.executable,'mail_worker.py']]
    try:
        for command in commands: children.append(subprocess.Popen(command))
        while not stopping:
            if any(p.poll() is not None for p in children):
                stop();return 1
            time.sleep(.5)
    finally:
        stop()
        for p in children:
            try: p.wait(timeout=25)
            except subprocess.TimeoutExpired: p.kill();p.wait()
    return 0

if __name__=='__main__': sys.exit(main())
