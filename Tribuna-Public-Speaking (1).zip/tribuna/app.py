"""Dependency-free WSGI application. Use Gunicorn behind HTTPS in production."""
import os, re, json, secrets, hashlib, hmac, sqlite3, mimetypes
from http.cookies import SimpleCookie
from urllib.parse import parse_qs, urlencode, urlsplit
from core import *
from domain import handle
import views

MAX_BODY=100_000
SECURE=BASE_URL.startswith('https://')
SESSION_AGE=8*3600
COOKIE='tribuna_session'
MULTI={'roles','judges','winners','public_rounds'}

def throttle(db,bucket,limit,window):
    bucket=digest(bucket);r=one(db,'SELECT * FROM attempts WHERE bucket=?',(bucket,))
    if r and r['until']>now():
        if r['count']>=limit: raise Problem('Muitas tentativas. Aguarde alguns minutos.',429)
        db.execute('UPDATE attempts SET count=count+1 WHERE bucket=?',(bucket,))
    else: db.execute('INSERT INTO attempts VALUES (?,1,?) ON CONFLICT(bucket) DO UPDATE SET count=1,until=excluded.until',(bucket,now()+window))

def new_session(db,uid=None,old=None):
    if old: db.execute('DELETE FROM sessions WHERE token=?',(digest(old),))
    raw=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(32)
    db.execute('INSERT INTO sessions VALUES (?,?,?,?)',(digest(raw),uid,csrf,now()+SESSION_AGE))
    return raw,csrf

def application(env,start_response):
    scope_token=ACCESS_SCOPE.set(None)
    status=200;headers=[];payload=None;db=connect();ctx={'user':None,'csrf':'','notice':''};path=env.get('PATH_INFO','/');method=env.get('REQUEST_METHOD','GET');raw=None
    def redirect(location,notice=''):
        nonlocal status,headers,payload
        status=303
        if notice: location+=('&' if '?' in location else '?')+urlencode({'notice':notice})
        headers.append(('Location',location));payload=b''
    def set_cookie(token,clear=False):
        attrs=f'{COOKIE}={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={0 if clear else SESSION_AGE}'
        if SECURE: attrs+='; Secure'
        headers.append(('Set-Cookie',attrs))
    try:
        if method not in ('GET','POST','HEAD'): raise Problem('Método não permitido.',405)
        host=env.get('HTTP_HOST','')
        if path!='/health' and host and host!=urlsplit(BASE_URL).netloc: raise Problem('Host inválido.',400)
        if path in ('/static/style.css','/static/app.js'):
            f=ROOT/path.lstrip('/');payload=f.read_bytes();headers.append(('Content-Type','text/css; charset=utf-8' if path.endswith('css') else 'application/javascript; charset=utf-8'))
        elif path=='/health': payload=b'ok';headers.append(('Content-Type','text/plain'))
        else:
            cookie=SimpleCookie()
            try: cookie.load(env.get('HTTP_COOKIE',''))
            except Exception: pass
            raw=cookie[COOKIE].value if COOKIE in cookie else None
            session=one(db,'SELECT * FROM sessions WHERE token=? AND expires>?',(digest(raw),now())) if raw else None
            if session:
                user=one(db,'SELECT id,username,email,name,society,moderator,organizer,active FROM users WHERE id=?',(session['user_id'],)) if session['user_id'] else None
                grant=one(db,'SELECT l.* FROM session_links s JOIN judge_links l ON l.id=s.link WHERE s.session=?',(session['token'],))
                if grant:
                    member=one(db,'SELECT roles FROM memberships WHERE c=? AND u=?',(grant['c'],grant['u']))
                    valid=grant['revoked']==0 and grant['expires']>now() and member and set(json.loads(member['roles']))&{'SM','NSM'}
                    if not valid:
                        db.execute('DELETE FROM sessions WHERE token=?',(session['token'],));session=None;user=None
                    elif user:
                        user['moderator']=0;user['organizer']=0
                        ctx['private_c']=grant['c'];ACCESS_SCOPE.set(dict(c=grant['c'],u=user['id']))
                if user and not user['active']: session=None
                elif session: ctx.update(user=user,csrf=session['csrf'])
            if not session:
                raw,csrf=new_session(db);set_cookie(raw);ctx['csrf']=csrf
            query=parse_qs(env.get('QUERY_STRING',''));q={k:v[-1] for k,v in query.items()};ctx['notice']=q.get('notice','')[:500]
            if method=='POST':
                try: length=int(env.get('CONTENT_LENGTH','0'))
                except ValueError: raise Problem('Requisição inválida.')
                if length<0 or length>MAX_BODY: raise Problem('Formulário muito grande.',413)
                if env.get('CONTENT_TYPE','').split(';')[0]!='application/x-www-form-urlencoded': raise Problem('Formato inválido.',415)
                origin=env.get('HTTP_ORIGIN')
                if origin and origin!=BASE_URL: raise Problem('Origem inválida.',403)
                parsed=parse_qs(env['wsgi.input'].read(length).decode('utf-8'),keep_blank_values=True,max_num_fields=300)
                data={k:(v if k in MULTI else v[-1]) for k,v in parsed.items()}
                if not hmac.compare_digest(str(data.get('csrf','')),ctx['csrf']): raise Problem('Formulário expirado. Atualize a página.',403)
                if path=='/login':
                    throttle(db,'login-ip:'+env.get('REMOTE_ADDR',''),30,900)
                    username=required(data,'username',254).lower();throttle(db,'login-user:'+username,10,900)
                    u=one(db,'SELECT * FROM users WHERE username=? OR email=?',(username,username))
                    password=str(data.get('password',''))[:201]
                    valid=password_ok(password,u['password'] if u else '0'*32+':'+'0'*128)
                    if not u or not u['active'] or not valid:
                        status=401;ctx['notice']='Usuário ou senha inválidos.';payload=views.auth_page(ctx,'login').encode()
                    else:
                        raw,ctx['csrf']=new_session(db,u['id'],raw);set_cookie(raw);redirect('/')
                elif path=='/forgot':
                    throttle(db,'forgot-ip:'+env.get('REMOTE_ADDR',''),5,900)
                    address=email(required(data,'email'));u=one(db,'SELECT * FROM users WHERE email=? AND active=1',(address,))
                    if u:
                        token=secrets.token_urlsafe(32)
                        with transaction(db):
                            db.execute('UPDATE resets SET used=1 WHERE u=?',(u['id'],));db.execute('INSERT INTO resets VALUES (?,?,?,0)',(digest(token),u['id'],now()+1800))
                            enqueue(db,None,address,'Tribuna — recuperar senha','Use este link em até 30 minutos:\n'+BASE_URL+'/reset?token='+token)
                    redirect('/login','Se o e-mail estiver cadastrado, as instruções de recuperação serão enviadas.')
                elif path=='/reset':
                    throttle(db,'reset-ip:'+env.get('REMOTE_ADDR',''),10,900)
                    with transaction(db):
                        token=digest(required(data,'token'));r=one(db,'SELECT * FROM resets WHERE token=? AND used=0 AND expires>?',(token,now()))
                        if not r: raise Problem('Link inválido ou expirado.')
                        ph=password_hash(required(data,'password',200));db.execute('UPDATE users SET password=? WHERE id=?',(ph,r['u']));db.execute('UPDATE resets SET used=1 WHERE u=?',(r['u'],));db.execute('DELETE FROM sessions WHERE user_id=?',(r['u'],));audit(db,None,r['u'],'Senha redefinida',r['u'])
                    set_cookie('',True);redirect('/login','Senha alterada. Entre novamente.')
                elif path=='/invite':
                    if ctx.get('private_c'): raise Problem('Entre com usuário e senha para aceitar convites de conta.',403)
                    throttle(db,'invite-ip:'+env.get('REMOTE_ADDR',''),15,900)
                    with transaction(db): uid=consume_invite(db,required(data,'token'),data,ctx['user'])
                    raw,ctx['csrf']=new_session(db,uid,raw);set_cookie(raw);redirect('/','Convite aceito.')
                elif path=='/judge':
                    throttle(db,'judge-ip:'+env.get('REMOTE_ADDR',''),30,900)
                    with transaction(db):
                        grant=judge_link(db,required(data,'token',200))
                        raw,ctx['csrf']=new_session(db,grant['u'],raw)
                        db.execute('INSERT INTO session_links VALUES (?,?)',(digest(raw),grant['id']))
                        audit(db,grant['c'],grant['u'],'Acesso por link privado',grant['id'],after='Sessão individual iniciada')
                    set_cookie(raw);redirect(f"/t/{grant['c']}?tab=scores")
                else:
                    if not ctx['user']: raise Problem('Entre na sua conta para continuar.',401)
                    u=ctx['user'];uid=u['id'];operation=required(data,'operation',100)
                    if ctx.get('private_c') and path!='/logout':
                        private_match=re.fullmatch(r'/t/(\d+)/([a-z_]+)',path)
                        if not private_match or int(private_match[1])!=ctx['private_c']: raise Problem('Este link só dá acesso à organização do campeonato correspondente.',403)
                    with transaction(db):
                        if one(db,'SELECT 1 FROM operations WHERE user=? AND token=?',(uid,operation)): raise Problem('Esta operação já foi processada. Atualize a página.',409)
                        db.execute('INSERT INTO operations VALUES (?,?)',(uid,operation))
                        if path=='/logout':
                            db.execute('DELETE FROM sessions WHERE token=?',(digest(raw),));set_cookie('',True);redirect('/login')
                        elif path=='/create':
                            if not u['organizer']: raise Problem('A moderação precisa autorizar você como organizador.',403)
                            cid=db.execute('INSERT INTO competitions(name,config,created_by) VALUES (?,?,?)',(required(data,'name',200),js(DEFAULTS),uid)).lastrowid
                            db.execute('INSERT INTO memberships VALUES (?,?,?)',(cid,uid,js(['organizer'])));db.executemany("INSERT INTO rounds VALUES (?,?,'draft')",[(cid,n) for n in (1,2,3)])
                            audit(db,cid,uid,'Campeonato criado',cid,after=dict(name=data['name']));redirect('/t/'+str(cid))
                        elif path.startswith('/admin/'):
                            if not u['moderator']: raise Problem('Somente a moderação global.',403)
                            if path=='/admin/invite': issue_invite(db,u,data)
                            elif path=='/admin/society':
                                name=required(data,'name',100);db.execute('INSERT OR IGNORE INTO societies VALUES (?)',(name,));audit(db,None,uid,'Sociedade cadastrada',name)
                            elif path=='/admin/permissions':
                                target=integer(data,'user',1);old=one(db,'SELECT id,moderator,organizer,active FROM users WHERE id=?',(target,))
                                if not old: raise Problem('Conta inválida.')
                                after={k:int(data.get(k)=='yes') for k in ('moderator','organizer','active')}
                                if old['moderator'] and old['active'] and not(after['moderator'] and after['active']) and one(db,'SELECT COUNT(*) AS n FROM users WHERE moderator=1 AND active=1')['n']<=1: raise Problem('Mantenha ao menos um moderador global ativo.')
                                why=required(data,'reason',2000);db.execute('UPDATE users SET moderator=?,organizer=?,active=? WHERE id=?',(after['moderator'],after['organizer'],after['active'],target));audit(db,None,uid,'Permissões globais alteradas',target,old,after,why)
                            else: raise Problem('Página inexistente.',404)
                            redirect('/admin','Alteração registrada.')
                        else:
                            m=re.fullmatch(r'/t/(\d+)/([a-z_]+)',path)
                            if not m: raise Problem('Página inexistente.',404)
                            cid=int(m[1]);action=m[2];handle(db,u,cid,action,data)
                            tabs={'participant':'participants','participant_status':'participants','invite':'team','society':'team','member_remove':'team','judge_add':'team','judge_link':'team','judge_revoke':'team','publish':'publication','score':'scores','waiver':'scores' if roles(db,cid,uid)&{'SM','NSM'} else 'rankings','conflict':'equity','conflict_remove':'equity','lottery':'rankings','top_options':'rankings','break':'finals','decision':'finals','reserve':'finals','mail_save':'emails','mail_send':'emails','settings':'settings'}
                            tab=tabs.get(action,'rooms');redirect(f'/t/{cid}?tab={tab}','Operação registrada com sucesso.')
            elif path=='/judge':
                grant=judge_link(db,q.get('token',''));payload=views.judge_entry(ctx,db,grant,q.get('token','')).encode()
            elif path in ('/login','/forgot','/reset','/invite'):
                payload=views.auth_page(ctx,path[1:],q.get('token','')).encode()
            elif path=='/public' or (path=='/' and not ctx['user']): payload=views.public_home(ctx,db).encode()
            elif re.fullmatch(r'/public/\d+',path): payload=views.public_tournament(ctx,db,int(path.split('/')[-1]),q.get('tab','overview')).encode()
            elif not ctx['user']: redirect('/login')
            elif path=='/':
                if ctx.get('private_c'): redirect('/t/'+str(ctx['private_c']))
                else: payload=views.home(ctx,db).encode()
            elif path=='/admin':
                if not ctx['user']['moderator']: raise Problem('Somente a moderação global.',403)
                payload=views.admin_page(ctx,db).encode()
            else:
                match=re.fullmatch(r'/t/(\d+)',path)
                if not match: raise Problem('Página inexistente.',404)
                cid=int(match[1]);rr=allow(db,cid,ctx['user']['id']);ctx.update(c=competition(db,cid),roles=rr,tab=q.get('tab','equity' if rr=={'equity'} else 'overview'))
                payload=views.tournament_page(ctx,db).encode()
    except Problem as err:
        status=err.status;payload=views.layout(ctx,'Não foi possível concluir','<div class="notice warning">'+views.e(err.message)+'</div>'+views.link('/','Voltar aos campeonatos','button-link')).encode()
    except sqlite3.IntegrityError:
        status=409;payload=views.layout(ctx,'Registro em conflito','<div class="notice warning">Este registro já existe ou está vinculado a outra operação. Confira os dados e atualize a página.</div>').encode()
    except Exception:
        import traceback
        traceback.print_exc()
        status=500;payload=views.layout(ctx,'Não foi possível concluir','<div class="notice warning">Ocorreu um erro interno. A operação não foi confirmada.</div>').encode()
    finally:
        db.close();ACCESS_SCOPE.reset(scope_token)
    if payload is None: payload=b''
    if not any(k=='Content-Type' for k,v in headers): headers.append(('Content-Type','text/html; charset=utf-8'))
    headers += [('Cache-Control','no-store'),('X-Content-Type-Options','nosniff'),('Referrer-Policy','same-origin'),('X-Frame-Options','DENY'),('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'none'"),('Permissions-Policy','camera=(), microphone=(), geolocation=()'),('Content-Length',str(len(payload)))]
    if SECURE: headers.append(('Strict-Transport-Security','max-age=31536000'))
    labels={200:'OK',303:'See Other',400:'Bad Request',401:'Unauthorized',403:'Forbidden',404:'Not Found',405:'Method Not Allowed',409:'Conflict',413:'Payload Too Large',415:'Unsupported Media Type',429:'Too Many Requests',500:'Internal Server Error'}
    start_response(str(status)+' '+labels.get(status,'Error'),headers)
    return [b'' if method=='HEAD' else payload]

if __name__=='__main__':
    from wsgiref.simple_server import make_server,WSGIRequestHandler
    class PrivateHandler(WSGIRequestHandler):
        def log_message(self,format,*args): pass
    init()
    print('Tribuna local: '+BASE_URL+' (servidor de desenvolvimento)')
    with make_server('127.0.0.1',8000,application,handler_class=PrivateHandler) as server: server.serve_forever()
