"""Disposable demonstration, explicitly enabled by DEMO_PASSWORD at startup."""
import os
from core import *

def seed():
    password=os.environ.get('DEMO_PASSWORD')
    if not password: raise SystemExit('DEMO_PASSWORD is required for this demonstration')
    init()
    db=connect()
    with transaction(db):
        if one(db,'SELECT id FROM users LIMIT 1'): return
        def user(login,name,role):
            uid=db.execute('INSERT INTO users(username,email,name,society,password,moderator,organizer) VALUES (?,?,?,?,?,?,?)',(login,login+'@example.test',name,'SDS UFBA',password_hash(password),int(role=='organizer'),int(role=='organizer'))).lastrowid
            return uid
        org=user('gustavo','Gustavo — demonstração','organizer')
        j1=user('sm','SM — demonstração','SM');j2=user('nsm','NSM — demonstração','NSM')
        eq=user('equidade','Equidade — demonstração','equity')
        for complete in (False,True):
            config=dict(DEFAULTS)
            config['public']=dict(PUBLIC_DEFAULTS,enabled=True,roster=True,team=True,rounds=[1,2,3],rankings=complete,intro='Demonstração do Tribuna. Dados fictícios e descartáveis. Não cadastre dados reais: as alterações podem ser apagadas quando o servidor reiniciar.')
            c=db.execute('INSERT INTO competitions(name,config,created_by) VALUES (?,?,?)',('Copa demonstração — '+('resultados' if complete else 'lançamento de notas'),js(config),org)).lastrowid
            for uid,role in [(org,'organizer'),(j1,'SM'),(j2,'NSM'),(eq,'equity')]: db.execute('INSERT INTO memberships VALUES (?,?,?)',(c,uid,js([role])))
            speakers=[]
            for i,name in enumerate(['Ana Lima','Bruno Souza','Clara Alves','Daniel Reis','Elisa Santos','Felipe Costa']):
                speakers.append(db.execute('INSERT INTO participants(c,name,email,society) VALUES (?,?,?,?)',(c,name,f'orador{i}@example.test',SOCIETIES[i%len(SOCIETIES)])).lastrowid)
            for n in (1,2,3):
                db.execute('INSERT INTO rounds VALUES (?,?,?)',(c,n,'closed' if complete else 'open'))
                room=db.execute('INSERT INTO rooms(c,n,name,chair) VALUES (?,?,?,?)',(c,n,'Palco',j1)).lastrowid
                for uid in (j1,j2): db.execute('INSERT INTO panels VALUES (?,?)',(room,uid))
                for i,p in enumerate(speakers):
                    db.execute('INSERT INTO placements VALUES (?,?,?,?,?)',(c,n,p,room,i+1))
                    if complete:
                        for uid in (j1,j2):
                            values=[9+(i+n+k)%5 for k in range(5)]
                            values[0]+=int(uid==j2)
                            db.execute('INSERT INTO scores(c,p,n,j,values_json,submitted_by) VALUES (?,?,?,?,?,?)',(c,p,n,uid,js(values),uid))
            audit(db,c,org,'demo_seed','competition',after={'fictitious':True},reason='Dados de demonstração')
    db.close()

if __name__=='__main__': seed()
